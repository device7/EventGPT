﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Events
{
    public class Ivykis
    {
        public string Apimtis;
        public string Apimtis_indeksas;
        public string Apimtis_ilgis;

        public string Tipas;

        public string Trigeris;
        public string Trigeris_indeksas;
        public string Trigeris_ilgis;

        public string Laikas;
        public string Laikas_indeksas;
        public string Laikas_ilgis;
    }
}
