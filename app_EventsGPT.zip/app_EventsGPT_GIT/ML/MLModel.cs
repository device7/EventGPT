﻿using Microsoft.ML;
using Microsoft.ML.Data;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Events.ML
{
    public class MLModel
    {
        MLContext mlContext = new MLContext();

        byte[] modelData;
        ITransformer model;

        public MLModel(string version, string algo) 
        {
            // Load model data from database
            modelData = LoadModelFromDatabase(version, algo);

            // Deserialize the model
            model = DeserializeModel(modelData, mlContext);
        }

        public void CreateNewModel(string version, string algo)
        {
            // load all the data for training the model
            IEnumerable <InputData> allData = LoadDataFromDatabaseGptTrainingData(version); // input dataset version number
            List<InputData> dataList = allData.ToList();

            // Shuffle the data to ensure randomness
            dataList.Shuffle();

            // Calculate the index at which to split the data (80%)
            int trainingSize = (int)(dataList.Count * 0.9);

            // Split the data
            List<InputData> trainingData = dataList.Take(trainingSize).ToList();
            List<InputData> testingData = dataList.Skip(trainingSize).ToList();

            // transform data
            var mlContext = new MLContext();
            var dataView = mlContext.Data.LoadFromEnumerable(trainingData);
            var dataProcessPipeline = mlContext.Transforms.Conversion.MapValueToKey("Label", nameof(InputData.EventType))
                .Append(mlContext.Transforms.Text.FeaturizeText("Features", nameof(InputData.Sentence)));

            // algo selection

            var trainingPipeline = default(IEstimator<ITransformer>);

            if (algo == "SME")
            {
                var trainer = mlContext.MulticlassClassification.Trainers.SdcaMaximumEntropy("Label", "Features")
                    .Append(mlContext.Transforms.Conversion.MapKeyToValue("PredictedLabel"));
                trainingPipeline = dataProcessPipeline.Append(trainer);
            }
            else if (algo == "FT")
            {
                // Use FastTree as a binary trainer
                var binaryTrainer = mlContext.BinaryClassification.Trainers.FastTree();
                var trainer = mlContext.MulticlassClassification.Trainers.OneVersusAll(binaryTrainer)
                    .Append(mlContext.Transforms.Conversion.MapKeyToValue("PredictedLabel"));

                trainingPipeline = dataProcessPipeline.Append(trainer);
            }
            else if (algo == "LR")
            {
                var binaryTrainer = mlContext.BinaryClassification.Trainers.LbfgsLogisticRegression();
                var trainer = mlContext.MulticlassClassification.Trainers.OneVersusAll(binaryTrainer)
                    .Append(mlContext.Transforms.Conversion.MapKeyToValue("PredictedLabel"));
                trainingPipeline = dataProcessPipeline.Append(trainer);
            }
            else
            {
                throw new ArgumentException($"Algorithm '{algo}' is not supported.");
            }


            // training
            var trainedModel = trainingPipeline.Fit(dataView);

            // evaluation
            var testDataView = mlContext.Data.LoadFromEnumerable(testingData);

            // results
            var predictions = trainedModel.Transform(testDataView);
            var metrics = mlContext.MulticlassClassification.Evaluate(predictions);

            string notes = ($"Macro accuracy: {metrics.MacroAccuracy:P2}");
            notes += "v2 ";
            notes += ($"Micro accuracy: {metrics.MicroAccuracy:P2}");
            notes += " GPT training set";

            byte[] serialized_model = SerializeModelToByteArray(trainedModel, dataView.Schema, mlContext);

            SaveModelToDatabase(serialized_model, notes, version, algo);
        }

        public void SaveModelToDatabaseV1(byte[] modelData, string notes)
        {
            Connection c = new Connection();

            using (var connection = new SqlConnection(c.con))
            {
                connection.Open();
                var command = new SqlCommand("INSERT INTO ktu_models (model, notes) VALUES (@ModelData,@notes)", connection);
                command.Parameters.AddWithValue("@ModelData", modelData);
                command.Parameters.AddWithValue("@notes", notes);

                command.ExecuteNonQuery();
            }
        }

        public void SaveModelToDatabase(byte[] modelData, string notes, string version, string algo)
        {
            Connection c = new Connection();

            using (var connection = new SqlConnection(c.con))
            {
                connection.Open();
                var command = new SqlCommand("INSERT INTO ktu_models (model, notes, version, algo) VALUES (@ModelData,@notes,@version,@algo)", connection);
                command.Parameters.AddWithValue("@ModelData", modelData);
                command.Parameters.AddWithValue("@notes", notes);
                command.Parameters.AddWithValue("@version", version);
                command.Parameters.AddWithValue("@algo", algo);

                command.ExecuteNonQuery();
            }
        }

        public string Predict(string sentence)
        {


            return PredictSentence(sentence, model, mlContext);

            // Use the model to make a prediction
            //string sentence = "Enter your test sentence here";
            //string prediction = PredictSentence(sentence, model, mlContext);

            //MessageBox.Show($"Prediction: {prediction}");
        }

        public ITransformer DeserializeModel(byte[] modelData, MLContext mlContext)
        {
            using (var stream = new MemoryStream(modelData))
            {
                return mlContext.Model.Load(stream, out DataViewSchema schema);
            }
        }

        public class InputD
        {
            public string Sentence { get; set; }
        }

        public class PredictionRes
        {
            [ColumnName("PredictedLabel")]
            public string PredictedLabel { get; set; }
        }


        public string PredictSentence(string sentence, ITransformer model, MLContext mlContext)
        {
            var predictionEngine = mlContext.Model.CreatePredictionEngine<InputData, PredictionRes>(model);
            var inputData = new InputData { Sentence = sentence };
            var result = predictionEngine.Predict(inputData);
            return result.PredictedLabel;
        }

        public byte[] LoadModelFromDatabase(string version, string algo)
        {
            Connection c = new Connection();

            byte[] modelData = null;
            using (var connection = new SqlConnection(c.con))
            {
                connection.Open();
                string komanda = string.Format("SELECT model FROM ktu_models WHERE version = '{0}' and algo = '{1}'", version, algo);
                var command = new SqlCommand(komanda, connection); // Adjust ID as needed
                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        modelData = (byte[])reader["model"];
                    }
                }
            }
            return modelData;
        }

        public byte[] SerializeModelToByteArray(ITransformer model, DataViewSchema schema, MLContext mlContext)
        {
            using (var stream = new MemoryStream())
            {
                mlContext.Model.Save(model, schema, stream);
                return stream.ToArray();
            }
        }

        //public List<InputData> LoadDataFromDatabaseGptTrainingData()
        //{
        //    Connection c = new Connection();
        //    var sqlCommandText = "SELECT [Sentence],[EventType] FROM [Cobra].[dbo].[ktu_gpt_training_data] where v2 = 0";

        //    var results = new List<InputData>();

        //    using (var connection = new SqlConnection(c.con))
        //    {
        //        var command = new SqlCommand(sqlCommandText, connection);
        //        connection.Open();

        //        using (var reader = command.ExecuteReader())
        //        {
        //            while (reader.Read())
        //            {
        //                var inputData = new InputData
        //                {
        //                    Sentence = reader["Sentence"].ToString(),
        //                    EventType = reader["EventType"].ToString()
        //                };
        //                results.Add(inputData);
        //            }
        //        }
        //    }

        //    return results;
        //}

        public List<InputData> LoadDataFromDatabaseGptTrainingData(string version)
        {
            Connection c = new Connection();
            var sqlCommandText = string.Format("SELECT [Sentence],[EventType] FROM [Cobra].[dbo].[ktu_gpt_training_data] where version = '{0}'", version);

            var results = new List<InputData>();

            using (var connection = new SqlConnection(c.con))
            {
                var command = new SqlCommand(sqlCommandText, connection);
                connection.Open();

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var inputData = new InputData
                        {
                            Sentence = reader["Sentence"].ToString(),
                            EventType = reader["EventType"].ToString()
                        };
                        results.Add(inputData);
                    }
                }
            }

            return results;
        }

        public List<InputData> LoadDataFromDatabaseTrigeriuZodynas()
        {
            Connection c = new Connection();
            var sqlCommandText = "SELECT [sakinys],[ivykio_tipas] FROM [Cobra].[dbo].[ktu_trigeriuzodynas]";

            var results = new List<InputData>();

            using (var connection = new SqlConnection(c.con))
            {
                var command = new SqlCommand(sqlCommandText, connection);
                connection.Open();

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var inputData = new InputData
                        {
                            Sentence = reader["sakinys"].ToString(),
                            EventType = reader["ivykio_tipas"].ToString()
                        };
                        results.Add(inputData);
                    }
                }
            }

            return results;
        }
    }
}
