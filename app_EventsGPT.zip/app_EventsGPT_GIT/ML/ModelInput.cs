﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Events.ML
{
    public class ModelInput : InputData
    {
        public float Label { get; set; }  // Numeric label after conversion
    }
}
