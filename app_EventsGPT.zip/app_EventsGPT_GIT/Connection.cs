﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Events
{
    public class Connection
    {
        // set correct connection string
        public string con = "Server=,1433;Initial Catalog=Cobra;Persist Security Info=False;User ID=sa;Password=;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=True;Connection Timeout=30;";
        public string secure = "";
    }
}
