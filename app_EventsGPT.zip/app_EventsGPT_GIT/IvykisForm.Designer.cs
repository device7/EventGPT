﻿namespace Events
{
    partial class IvykisForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ivykismentionBox = new RichTextBox();
            ivykiotipasCombo = new ComboBox();
            label3 = new Label();
            label4 = new Label();
            label2 = new Label();
            ivykiolaikasBox = new TextBox();
            ivykiotrigerisBox = new TextBox();
            naikintiButton = new Button();
            okButton = new Button();
            SuspendLayout();
            // 
            // ivykismentionBox
            // 
            ivykismentionBox.Location = new Point(107, 32);
            ivykismentionBox.Name = "ivykismentionBox";
            ivykismentionBox.ReadOnly = true;
            ivykismentionBox.Size = new Size(485, 120);
            ivykismentionBox.TabIndex = 0;
            ivykismentionBox.Text = "";
            // 
            // ivykiotipasCombo
            // 
            ivykiotipasCombo.DropDownStyle = ComboBoxStyle.DropDownList;
            ivykiotipasCombo.FormattingEnabled = true;
            ivykiotipasCombo.Location = new Point(107, 188);
            ivykiotipasCombo.Name = "ivykiotipasCombo";
            ivykiotipasCombo.Size = new Size(485, 28);
            ivykiotipasCombo.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(41, 277);
            label3.Name = "label3";
            label3.Size = new Size(60, 20);
            label3.TabIndex = 2;
            label3.Text = "Trigeris:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(54, 191);
            label4.Name = "label4";
            label4.Size = new Size(47, 20);
            label4.TabIndex = 3;
            label4.Text = "Tipas:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(49, 235);
            label2.Name = "label2";
            label2.Size = new Size(52, 20);
            label2.TabIndex = 4;
            label2.Text = "Laikas:";
            // 
            // ivykiolaikasBox
            // 
            ivykiolaikasBox.Location = new Point(107, 232);
            ivykiolaikasBox.Name = "ivykiolaikasBox";
            ivykiolaikasBox.ReadOnly = true;
            ivykiolaikasBox.Size = new Size(485, 27);
            ivykiolaikasBox.TabIndex = 5;
            // 
            // ivykiotrigerisBox
            // 
            ivykiotrigerisBox.Location = new Point(107, 274);
            ivykiotrigerisBox.Name = "ivykiotrigerisBox";
            ivykiotrigerisBox.ReadOnly = true;
            ivykiotrigerisBox.Size = new Size(485, 27);
            ivykiotrigerisBox.TabIndex = 6;
            // 
            // naikintiButton
            // 
            naikintiButton.Location = new Point(498, 375);
            naikintiButton.Name = "naikintiButton";
            naikintiButton.Size = new Size(94, 29);
            naikintiButton.TabIndex = 7;
            naikintiButton.Text = "Naikinti";
            naikintiButton.UseVisualStyleBackColor = true;
            naikintiButton.Click += naikintiButton_Click_1;
            // 
            // okButton
            // 
            okButton.Location = new Point(318, 355);
            okButton.Name = "okButton";
            okButton.Size = new Size(107, 69);
            okButton.TabIndex = 8;
            okButton.Text = "OK";
            okButton.UseVisualStyleBackColor = true;
            okButton.Click += okButton_Click_1;
            // 
            // IvykisForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(728, 450);
            Controls.Add(okButton);
            Controls.Add(naikintiButton);
            Controls.Add(ivykiotrigerisBox);
            Controls.Add(ivykiolaikasBox);
            Controls.Add(label2);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(ivykiotipasCombo);
            Controls.Add(ivykismentionBox);
            Name = "IvykisForm";
            Text = "IvykisForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RichTextBox ivykismentionBox;
        private ComboBox ivykiotipasCombo;
        private Label label3;
        private Label label4;
        private Label label2;
        private TextBox ivykiolaikasBox;
        private TextBox ivykiotrigerisBox;
        private Button naikintiButton;
        private Button okButton;
    }
}