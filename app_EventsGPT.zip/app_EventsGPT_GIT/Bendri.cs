﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Events
{
    public class Bendri
    {

        public void form_nustatymai_default(Form form, string name)
        {
            // darom default rezoliucijai: 1366x768.
            // tai ziureti, kad nevirsytu sios rezoliucijos lango matmenys ir viskas bus gerai. (kitaip isikraipys).
            form.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            form.Text = name;
            form.FormBorderStyle = FormBorderStyle.FixedSingle;
            form.MaximizeBox = false;
            form.BackColor = Color.White;
            // desimtainiams naudoti skyrikli taska del sql
            System.Globalization.CultureInfo customCulture = (System.Globalization.CultureInfo)System.Threading.Thread.CurrentThread.CurrentCulture.Clone();
            customCulture.NumberFormat.NumberDecimalSeparator = ".";
            System.Threading.Thread.CurrentThread.CurrentCulture = customCulture;
        }

        public bool IsValidJson(string jsonString)
        {
            try
            {
                var obj = JsonConvert.DeserializeObject(jsonString);
                return true;
            }
            catch (JsonReaderException)
            {
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
