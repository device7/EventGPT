﻿using Catalyst;
using edu.stanford.nlp.ling;
using edu.stanford.nlp.pipeline;
using ExtensionMethods;
using java.util;
using jdk.nashorn.@internal.ir;
using Microsoft.ML.Data;
using Microsoft.ML;
using Mosaik.Core;
using Newtonsoft.Json;
using System.Data;
using System.Data.SqlClient;
using static edu.stanford.nlp.ie.KBPRelationExtractor;
using static System.Net.Mime.MediaTypeNames;
using Events.ML;
using com.sun.org.apache.bcel.@internal.generic;
using java.awt.geom;
using jdk.nashorn.@internal.scripts;
using org.joda.time;
using static javax.swing.text.Position;
using sun.security.x509;
using System.Text.RegularExpressions;
using static OpenAI.ObjectModels.SharedModels.IOpenAiModels;
using com.sun.xml.@internal.bind.v2.schemagen.xmlschema;
using Annotation = edu.stanford.nlp.pipeline.Annotation;
using com.sun.istack.@internal;

// stebeti usage https://platform.openai.com/settings/organization/billing/overview
// modeliai: https://platform.openai.com/docs/models

//gemini api: AIzaSyCnlaraQWS-1VP-mth-RIoWhVrUN82ueBI
//duratailt@gmail.com !iBwXHn*B[p8
// https://aistudio.google.com/app/apikey
// https://console.cloud.google.com/apis/api/generativelanguage.googleapis.com/metrics?project=gen-lang-client-0836368521&pli=1
// eur kiek like gemini https://console.cloud.google.com/billing/01DD92-9F467A-61F99D/reports;timeRange=CUSTOM_RANGE;from=2024-06-19;to=2024-09-19;timeGrouping=GROUP_BY_MONTH;projects=gen-lang-client-0836368521;products=services%2FAEFD-7695-64FA?project=gen-lang-client-0836368521

namespace Events
{
    public partial class ivykiaiForm : Form
    {
        int total_events_annotated = 0;

        MLModel MLmodel; // = new MLModel();
        Bendri b;
        ContextMenuStrip meniu = new ContextMenuStrip();

        Anotacijos anotacijos_obj;
        //Anotacijos anotacijos_obj_gpt4prev;

        string ikrauto_straipsnio_id;

        string[,] ivykiu_trigeriu_zodynas;

        //string straipsnio_anotacijos_gpt = "";
        //string straipsnio_etalonines_anotacijos = "";
        public ivykiaiForm()
        {
            InitializeComponent();

            b = new Bendri();

            b.form_nustatymai_default(this, "Įvykiai");

            ikrauti_datas();

            //kategorijaCombo.SelectedIndexChanged += KategorijaCombo_SelectedIndexChanged;
            dataCombo.SelectedIndexChanged += DataCombo_SelectedIndexChanged;
            straipsniaiCombo.SelectedIndexChanged += StraipsniaiCombo_SelectedIndexChanged;

            kontekstinis_meniu();
            baigtasCheck.CheckedChanged += BaigtasCheck_CheckedChanged;
            idBox.KeyDown += IdBox_KeyDown;

            ivykiu_zodyno_ikelimas();
        }

        void ivykiu_zodyno_ikelimas()
        {
            ivykiu_trigeriu_zodynas = "select trigeris, ivykio_tipas from ktu_trigeriuzodynas".ToSqlSelect();
        }

        private void IdBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                ikrauti_straipsni(idBox.Text.ToString());
            }
        }

        private void BaigtasCheck_CheckedChanged(object sender, EventArgs e)
        {
            issaugotianotacijasButton.Visible = true;
        }

        private void kontekstinis_meniu()
        {
            meniu = new ContextMenuStrip();
            ToolStripMenuItem naujas_ivykis = new ToolStripMenuItem("Įvykis");
            ToolStripMenuItem gpt = new ToolStripMenuItem("GPT");

            naujas_ivykis.Click += NaujasIvykis_Click;
            //gpt.Click += Gpt_Click;

            meniu.Items.AddRange(new ToolStripItem[] { naujas_ivykis });

            // papildomi eventai
            straipsnisBox.MouseDown += StraipsnisBox_MouseDown;
        }

        private void Gpt_Click(object sender, EventArgs e)
        {
            string Text = straipsnisBox.SelectedText.Trim();

            gpt_annotation(Text, 0, null, null);
        }

        Ivykis LLM_annotation_new_framework(string sakinys, int pradzios_indeksas, string straipsnio_id, string db_column, string llm)
        {
            string uzduotis = "Užduoties aprašymas" + Environment.NewLine + Environment.NewLine;
            //float temperatura = 1F;

            uzduotis += "Tai yra 1 iš 2 įvykių tipų nustatymo: Kontaktas.Susitikimas arba Kontaktas.Telefonu-Rašytinis ir jų laiko nustatymo užduotis. Užduoties tekstu galimai pateikiamas tik 1 įvykis. Jeigu pateikiamas tekstas yra vienas iš reikiamų atpažinti įvykių, pateikti struktūrizuotą išvestį pagal pavyzdį. Kitu atveju, pateikti atsakymą: nenustatyta." + Environment.NewLine + Environment.NewLine;
            //uzduotis += "Įvykio aprašymas ir užduoties įvykių tipai" + Environment.NewLine + Environment.NewLine;
            //uzduotis += "Įvykis yra vyksmas, kuriame dalyvauja jo dalyviai. Įvykis yra kažkas kas įvyksta. Įvykį taip pat galima apibūdinti kaip būsenos pokytį." + Environment.NewLine + Environment.NewLine;
            uzduotis += "Įvykio ir jo tipų apibrėžimai naudojami iš Linguistic Data Consortium. (2005). ACE (Automatic Content Extraction) English Annotation Guidelines for Events." + Environment.NewLine + Environment.NewLine;
            //uzduotis += "1. Kontaktas.Susitikimas: 2 ar daugiau subjektų (turi būti paminėti pvz. žmonės, šalys, įmonės) susitikimas tam tikroje vietoje fiziškai (akis į akį). Įeina pokalbiai, summit'ai, konferencijos, vizitai ir kiti susitikimai. Tam, kad sakinys atitiktų įvykį: Kontaktas.Susitikimas, jame turi būti aiškiai nusakyta, kad susitikimas kažkur vyksta fiziškai t.y. žmonės kažkur susitiko akis į akį. Pvz. \"GM kalbasi su Chrysler dėl Jeep įsigyjimo\" - nelaikytina susitikimo įvykiu." + Environment.NewLine;
            //uzduotis += "2. Kontaktas.Telefonu-Rašytinis: 2 ar daugiau žmonių (turi būti paminėti) sukontaktuoja telefonu ar raštu (pvz. el. paštu) nuotoliu be fizinio susitikimo. \"Asmuo pasakė žurnalistams\" arba \"išleido pranešimą spaudai\" nėra šis įvykis." + Environment.NewLine + Environment.NewLine;
            uzduotis += "Pavyzdys:" + Environment.NewLine + Environment.NewLine;
            uzduotis += "Įvestis: Bušas ir Putinas šią savaitę susitiko aptarti reikalus dėl Čėčėnijos." + Environment.NewLine;
            uzduotis += "Išvestis: [{\"Trigeris\":\"susitiko\",\"Laikas\":\"šią savaitę\",\"Tipas\":\"Kontaktas.Susitikimas\"}]" + Environment.NewLine + Environment.NewLine;
            //uzduotis += "Įvestis: Džonas išsiuntė el. laišką Džeinei." + Environment.NewLine;
            //uzduotis += "Išvestis: [{\"Trigeris\":\"išsiuntė\",\"Laikas\":\"\",\"Tipas\":\"Telefonu-Rašytinis\"}]" + Environment.NewLine + Environment.NewLine;
            //uzduotis += "Blogi pavyzdžiai:" + Environment.NewLine + Environment.NewLine;
            //uzduotis += "Įvestis: GM jau metus kalbasi su Chrysler dėl Jeep įsigyjimo." + Environment.NewLine;
            //uzduotis += "Išvestis: [{\"Trigeris\":\"kalbasi\",\"Laikas\":\"metus\",\"Tipas\":\"Kontaktas.Susitikimas\"}]" + Environment.NewLine + Environment.NewLine;
            //uzduotis += "Įvestis: Prezidentas Nausėda pareiškė žurnalistas, kad kitais metais kandidatuos į prezidentus." + Environment.NewLine;
            //uzduotis += "Išvestis: [{\"Trigeris\":\"pareiškė\",\"Laikas\":\"kitais metais\",\"Tipas\":\"Telefonu-Rašytinis\"}]" + Environment.NewLine + Environment.NewLine;

            uzduotis += "Užduoties tekstas: " + Environment.NewLine;
            //uzduotis += "Raseinių rajone, Ariogaloje, spalio 3 dieną, mirė mažametis vaikas (2015 m.).";
            uzduotis += sakinys;

            // 1 tokenas ~ 4 angl. raides, tai cia apie iki 50 tokenu
            string rez = "";
            string initial_rez = "";

            int tryagain_count = 0;
            bool was_stressed = false;
            bool was_stressed2 = false;
        tryagain:

            if (llm == "gpt")
                initial_rez = uzduotis.ToGPT(0.7f, OpenAI.ObjectModels.Models.Gpt_4o);
            else if (llm == "gemini")
            {
                //Thread.Sleep(6000); // uztikrint 4s/min greiti, bet input size dar priklauso tai 4s->6s
                initial_rez = uzduotis.ToGemini();
            }

            if (initial_rez.Contains("Error"))
            {
                if (tryagain_count < 5)
                {
                    Thread.Sleep(12000);
                    tryagain_count++;
                    goto tryagain;
                }
                else
                {
                    MessageBox.Show("GEMINI ERROR (5 times in a row):" + rez);
                    Environment.Exit(0);
                }
            }

            Ivykis ivykis = new Ivykis();

            // jei ne ivykis praleidziama
            if (initial_rez.ToLower().Contains("nenustatyta") || initial_rez.ToLower().Contains("notsafe") || initial_rez.ToLower().Contains("[]") || initial_rez.ToLower().Contains("[ ]"))
            {
                // stressing

                if (!was_stressed) // darkart
                {
                    was_stressed = true;

                    uzduotis = "";
                    uzduotis += "Tu nustatei, kad šis sakinys: (" + sakinys + ") neatitinka nei vieno iš žemiau pateiktų įvykių. Darkart patikslink ar tikrai neatitinka nei vienos iš šių definicijų pateiktų apačioje. Jei taip, pateik struktūrizuotą išvestį pagal pavyzdį. Kitu atveju, pateikti atsakymą: nenustatyta." + Environment.NewLine + Environment.NewLine;
                    uzduotis += "Įvykio ir jo tipų apibrėžimai:" + Environment.NewLine + Environment.NewLine;
                    uzduotis += "1. Kontaktas.Susitikimas: 2 ar daugiau subjektų (turi būti paminėti pvz. žmonės, šalys, įmonės) susitikimas tam tikroje vietoje fiziškai (akis į akį). Įeina pokalbiai, summit'ai, konferencijos, vizitai ir kiti susitikimai. Tam, kad sakinys atitiktų įvykį: Kontaktas.Susitikimas, jame turi būti aiškiai nusakyta, kad susitikimas kažkur vyksta fiziškai t.y. žmonės kažkur susitiko akis į akį. Pvz. \"GM kalbasi su Chrysler dėl Jeep įsigyjimo\" - nelaikytina susitikimo įvykiu." + Environment.NewLine;
                    uzduotis += "2. Kontaktas.Telefonu-Rašytinis: 2 ar daugiau žmonių (turi būti paminėti) sukontaktuoja telefonu ar raštu (pvz. el. paštu) nuotoliu be fizinio susitikimo. \"Asmuo pasakė žurnalistams\" arba \"išleido pranešimą spaudai\" nėra šis įvykis." + Environment.NewLine + Environment.NewLine;
                    uzduotis += "Pavyzdys:" + Environment.NewLine + Environment.NewLine;
                    uzduotis += "Įvestis: Bušas ir Putinas šią savaitę susitiko aptarti reikalus dėl Čėčėnijos." + Environment.NewLine;
                    uzduotis += "Išvestis: [{\"Trigeris\":\"susitiko\",\"Laikas\":\"šią savaitę\",\"Tipas\":\"Kontaktas.Susitikimas\"}]" + Environment.NewLine + Environment.NewLine;
                    
                    goto tryagain;
                }
                else
                    goto praleisti;
            }
            else
            {
                // tipo nustate
                rez = ExtractBetweenBrackets(initial_rez); // kartais negraziai pateikia su papildomais simboliais
            }

            if (b.IsValidJson(rez))
            {
                int startIndex = rez.IndexOf('[');
                int endIndex = rez.IndexOf(']');
                string dataBetweenBrackets;

                try
                {
                    dataBetweenBrackets = rez.Substring(startIndex + 1, endIndex - startIndex - 1);
                }
                catch
                {
                    goto praleisti;
                }

                try
                {
                    ivykis = JsonConvert.DeserializeObject<Ivykis>(dataBetweenBrackets);
                }
                catch
                {
                    // anomalija gaunasi, kai sudetinis sakinys, tai isveda triguba rezultata
                    // tarsi ir teisingai dalinai


                    //MessageBox.Show("JSON konvertavimo klaida.");
                    //System.Environment.Exit(0);
                    return ivykis;
                }

                if (!was_stressed2)
                {
                    try
                    {
                        if (ivykis.Tipas == "Kontaktas.Susitikimas")
                        {
                            uzduotis = "";
                            uzduotis += "Tu nustatei, kad šis sakinys: (" + sakinys + ") atitinka Kontaktas.Susitikimas tipo įvykį pagal apibrėžimą pateiktą apačioje. Darkart patikslink ar tikrai: turi būti aiškiai įvardinta arba aiškiai galima numanyti, kad susitikimas tikrai vyksta fiziškai. Jei taip, pateik struktūrizuotą išvestį pagal pavyzdį. Kitu atveju, pateikti atsakymą: nenustatyta." + Environment.NewLine + Environment.NewLine;
                            uzduotis += "Įvykio ir jo tipų apibrėžimai:" + Environment.NewLine + Environment.NewLine;
                            uzduotis += "1. Kontaktas.Susitikimas: 2 ar daugiau subjektų (turi būti paminėti pvz. žmonės, šalys, įmonės) susitikimas tam tikroje vietoje fiziškai (akis į akį). Įeina pokalbiai, summit'ai, konferencijos, vizitai ir kiti susitikimai. Tam, kad sakinys atitiktų įvykį: Kontaktas.Susitikimas, jame turi būti aiškiai nusakyta, kad susitikimas kažkur vyksta fiziškai t.y. žmonės kažkur susitiko akis į akį. Pvz. \"GM kalbasi su Chrysler dėl Jeep įsigyjimo\" - nelaikytina susitikimo įvykiu." + Environment.NewLine;
                            uzduotis += "2. Kontaktas.Telefonu-Rašytinis: 2 ar daugiau žmonių (turi būti paminėti) sukontaktuoja telefonu ar raštu (pvz. el. paštu) nuotoliu be fizinio susitikimo. \"Asmuo pasakė žurnalistams\" arba \"išleido pranešimą spaudai\" nėra šis įvykis." + Environment.NewLine + Environment.NewLine;
                            uzduotis += "Pavyzdys:" + Environment.NewLine + Environment.NewLine;
                            uzduotis += "Įvestis: Bušas ir Putinas šią savaitę susitiko aptarti reikalus dėl Čėčėnijos." + Environment.NewLine;
                            uzduotis += "Išvestis: [{\"Trigeris\":\"susitiko\",\"Laikas\":\"šią savaitę\",\"Tipas\":\"Kontaktas.Susitikimas\"}]" + Environment.NewLine + Environment.NewLine;

                            was_stressed2 = true;
                            goto tryagain;

                        }
                        else if (ivykis.Tipas == "Kontaktas.Telefonu-Rašytinis")
                        {
                            uzduotis = "";
                            uzduotis += "Tu nustatei, kad šis sakinys: (" + sakinys + ") atitinka Kontaktas.Telefonu-Rašytinis tipo įvykį pagal apibrėžimą pateiktą apačioje. Darkart patikslink ar tikrai: turi būti aiškiai įvardinta arba aiškiai galima numanyti, kad susitikimas fiziškai neįvyko ir 2 objektai vienas su kitu turėjo kontaktą per nuotolį. Jei taip, pateik struktūrizuotą išvestį pagal pavyzdį. Kitu atveju, pateikti atsakymą: nenustatyta." + Environment.NewLine + Environment.NewLine;
                            uzduotis += "Įvykio ir jo tipų apibrėžimai:" + Environment.NewLine + Environment.NewLine;
                            uzduotis += "1. Kontaktas.Susitikimas: 2 ar daugiau subjektų (turi būti paminėti pvz. žmonės, šalys, įmonės) susitikimas tam tikroje vietoje fiziškai (akis į akį). Įeina pokalbiai, summit'ai, konferencijos, vizitai ir kiti susitikimai. Tam, kad sakinys atitiktų įvykį: Kontaktas.Susitikimas, jame turi būti aiškiai nusakyta, kad susitikimas kažkur vyksta fiziškai t.y. žmonės kažkur susitiko akis į akį. Pvz. \"GM kalbasi su Chrysler dėl Jeep įsigyjimo\" - nelaikytina susitikimo įvykiu." + Environment.NewLine;
                            uzduotis += "2. Kontaktas.Telefonu-Rašytinis: 2 ar daugiau žmonių (turi būti paminėti) sukontaktuoja telefonu ar raštu (pvz. el. paštu) nuotoliu be fizinio susitikimo. \"Asmuo pasakė žurnalistams\" arba \"išleido pranešimą spaudai\" nėra šis įvykis." + Environment.NewLine + Environment.NewLine;
                            uzduotis += "Pavyzdys:" + Environment.NewLine + Environment.NewLine;
                            uzduotis += "Įvestis: Bušas ir Putinas šią savaitę susitiko aptarti reikalus dėl Čėčėnijos." + Environment.NewLine;
                            uzduotis += "Išvestis: [{\"Trigeris\":\"susitiko\",\"Laikas\":\"šią savaitę\",\"Tipas\":\"Kontaktas.Susitikimas\"}]" + Environment.NewLine + Environment.NewLine;

                            was_stressed2 = true;
                            goto tryagain;
                        }
                    }
                    catch
                    {
                        uzduotis = "";
                        uzduotis += "Tu nustatei, kad šis sakinys: (" + sakinys + ") atitinka kažkurį iš ivykių, bet nepriskyrei jam tipo. Darkart patikslink. Jei atitinka įvykį, pateik struktūrizuotą išvestį pagal pavyzdį. Kitu atveju, pateikti atsakymą: nenustatyta." + Environment.NewLine + Environment.NewLine;
                        uzduotis += "Įvykio ir jo tipų apibrėžimai:" + Environment.NewLine + Environment.NewLine;
                        uzduotis += "1. Kontaktas.Susitikimas: 2 ar daugiau subjektų (turi būti paminėti pvz. žmonės, šalys, įmonės) susitikimas tam tikroje vietoje fiziškai (akis į akį). Įeina pokalbiai, summit'ai, konferencijos, vizitai ir kiti susitikimai. Tam, kad sakinys atitiktų įvykį: Kontaktas.Susitikimas, jame turi būti aiškiai nusakyta, kad susitikimas kažkur vyksta fiziškai t.y. žmonės kažkur susitiko akis į akį. Pvz. \"GM kalbasi su Chrysler dėl Jeep įsigyjimo\" - nelaikytina susitikimo įvykiu." + Environment.NewLine;
                        uzduotis += "2. Kontaktas.Telefonu-Rašytinis: 2 ar daugiau žmonių (turi būti paminėti) sukontaktuoja telefonu ar raštu (pvz. el. paštu) nuotoliu be fizinio susitikimo. \"Asmuo pasakė žurnalistams\" arba \"išleido pranešimą spaudai\" nėra šis įvykis." + Environment.NewLine + Environment.NewLine;
                        uzduotis += "Pavyzdys:" + Environment.NewLine + Environment.NewLine;
                        uzduotis += "Įvestis: Bušas ir Putinas šią savaitę susitiko aptarti reikalus dėl Čėčėnijos." + Environment.NewLine;
                        uzduotis += "Išvestis: [{\"Trigeris\":\"susitiko\",\"Laikas\":\"šią savaitę\",\"Tipas\":\"Kontaktas.Susitikimas\"}]" + Environment.NewLine + Environment.NewLine;

                        was_stressed2 = true;
                        goto tryagain;
                    }
                }

                ivykis.Apimtis = sakinys;
                ivykis.Apimtis_indeksas = pradzios_indeksas.ToString(); // cia reikia perduoti
                ivykis.Apimtis_ilgis = sakinys.Length.ToString();

                if (ivykis.Laikas.IsNotNullOrEmpty())
                {
                    int laikas_index = sakinys.ToLower().IndexOf(ivykis.Laikas.ToLower());

                    if (laikas_index != -1)
                    {
                        ivykis.Laikas_indeksas = (laikas_index).ToString(); // isskaiciuoti pagla apimties pradzia
                        ivykis.Laikas_ilgis = ivykis.Laikas.Length.ToString();

                        //MessageBox.Show("Klaida 02 (laikas) anotuojant straipsnį " + straipsnio_id);
                        //System.Environment.Exit(0);

                        // gali buti 2 laikai pvz sestadieni, ir sekmadieni
                        // ir gpt pazymi juos abu bet i viena lauka ir tada negali uztagint
                    }
                }
                else
                {
                    ivykis.Laikas_indeksas = "";
                    ivykis.Laikas_ilgis = "";
                }

                if (ivykis.Trigeris.IsNotNullOrEmpty())
                {
                    int trigeris_index = sakinys.ToLower().IndexOf(ivykis.Trigeris.ToLower());


                    if (trigeris_index != -1)
                    {
                        ivykis.Trigeris_indeksas = (trigeris_index).ToString();
                        ivykis.Trigeris_ilgis = ivykis.Trigeris.Length.ToString();

                        // buna tokia anomalija, kad GPT trigeriu nustato zodi, kurio net nera sakinyje

                        //MessageBox.Show("Klaida 02 (trigeris) anotuojant straipsnį " + straipsnio_id);
                        //System.Environment.Exit(0);
                    }
                }
                else
                {
                    ivykis.Trigeris_indeksas = "";
                    ivykis.Trigeris_ilgis = "";
                }


            }
            else
            {
                // nevalidus json
            }

        praleisti:

            return ivykis;

            //MessageBox.Show(string.Format("Sakinys: \n\n{0}\n\nGPT rezultatas: \n\n{1}", sakinys, rez));

        }

        public static string ExtractBetweenBrackets(string input)
        {
            // Regular expression to capture content between the first set of square brackets
            string pattern = @"\[.*?\]";
            Match match = Regex.Match(input, pattern);

            if (match.Success)
            {
                return match.Value;  // Return the content between brackets including brackets
            }

            return string.Empty;  // Return empty string if no match is found
        }

        Ivykis gpt_annotation(string sakinys, int pradzios_indeksas, string straipsnio_id, string metodika)
        {
            string uzduotis = "Užduoties aprašymas" + Environment.NewLine + Environment.NewLine;
            float temperatura = 0F;

            if (metodika == "1")
            {
                uzduotis += "Tai yra šioje užduotyje pateiktų 1 iš 2 įvykių tipų ir jų laiko nustatymo užduotis. Užduoties tekstu galimai pateikiamas tik 1 įvykis. Jeigu pateikiamas tekstas yra vienas iš reikiamų atpažinti įvykių, pateikti struktūrizuotą išvestį pagal pavyzdį. Kitu atveju, pateikti atsakymą: nenustatyta." + Environment.NewLine + Environment.NewLine;
                uzduotis += "Įvykio aprašymas ir užduoties įvykių tipai" + Environment.NewLine + Environment.NewLine;
                uzduotis += "Įvykis yra vyksmas, kuriame dalyvauja jo dalyviai. Įvykis yra kažkas kas įvyksta. Įvykį taip pat galima apibūdinti kaip būsenos pokytį." + Environment.NewLine + Environment.NewLine;
                uzduotis += "1. Kontaktas.Susitikimas: 2 ar daugiau subjektų (turi būti paminėti pvz. žmonės, šalys, įmonės) susitikimas tam tikroje vietoje fiziškai (akis į akį). Įeina pokalbiai, summit'ai, konferencijos, vizitai ir kiti susitikimai. Tam, kad sakinys atitiktų įvykį: Kontaktas.Susitikimas, jame turi būti aiškiai nusakyta, kad susitikimas kažkur vyksta fiziškai t.y. žmonės kažkur susitiko akis į akį. Pvz. \"GM kalbasi su Chrysler dėl Jeep įsigyjimo\" - nelaikytina susitikimo įvykiu." + Environment.NewLine;
                uzduotis += "2. Kontaktas.Telefonu-Rašytinis: 2 ar daugiau žmonių (turi būti paminėti) sukontaktuoja telefonu ar raštu (pvz. el. paštu) nuotoliu be fizinio susitikimo. \"Asmuo pasakė žurnalistams\" arba \"išleido pranešimą spaudai\" nėra šis įvykis." + Environment.NewLine + Environment.NewLine;
                uzduotis += "Geri pavyzdžiai:" + Environment.NewLine + Environment.NewLine;
                uzduotis += "Įvestis: Bušas ir Putinas šią savaitę susitiko aptarti reikalus dėl Čėčėnijos." + Environment.NewLine;
                uzduotis += "Išvestis: [{\"Trigeris\":\"susitiko\",\"Laikas\":\"šią savaitę\",\"Tipas\":\"Kontaktas.Susitikimas\"}]" + Environment.NewLine + Environment.NewLine;
                uzduotis += "Įvestis: Džonas išsiuntė el. laišką Džeinei." + Environment.NewLine;
                uzduotis += "Išvestis: [{\"Trigeris\":\"išsiuntė\",\"Laikas\":\"\",\"Tipas\":\"Telefonu-Rašytinis\"}]" + Environment.NewLine + Environment.NewLine;
                uzduotis += "Blogi pavyzdžiai:" + Environment.NewLine + Environment.NewLine;
                uzduotis += "Įvestis: GM jau metus kalbasi su Chrysler dėl Jeep įsigyjimo." + Environment.NewLine;
                uzduotis += "Išvestis: [{\"Trigeris\":\"kalbasi\",\"Laikas\":\"metus\",\"Tipas\":\"Kontaktas.Susitikimas\"}]" + Environment.NewLine + Environment.NewLine;
                uzduotis += "Įvestis: Prezidentas Nausėda pareiškė žurnalistas, kad kitais metais kandidatuos į prezidentus." + Environment.NewLine;
                uzduotis += "Išvestis: [{\"Trigeris\":\"pareiškė\",\"Laikas\":\"kitais metais\",\"Tipas\":\"Telefonu-Rašytinis\"}]" + Environment.NewLine + Environment.NewLine;
            }
            else if (metodika == "2")
            {
                // be blogu pavyzdziu
                uzduotis += "Tai yra šioje užduotyje pateiktų 1 iš 2 įvykių tipų ir jų laiko nustatymo užduotis. Užduoties tekstu galimai pateikiamas tik 1 įvykis. Jeigu pateikiamas tekstas yra vienas iš reikiamų atpažinti įvykių, pateikti struktūrizuotą išvestį pagal pavyzdį. Kitu atveju, pateikti atsakymą: nenustatyta." + Environment.NewLine + Environment.NewLine;
                uzduotis += "Įvykio aprašymas ir užduoties įvykių tipai" + Environment.NewLine + Environment.NewLine;
                uzduotis += "Įvykis yra vyksmas, kuriame dalyvauja jo dalyviai. Įvykis yra kažkas kas įvyksta. Įvykį taip pat galima apibūdinti kaip būsenos pokytį." + Environment.NewLine + Environment.NewLine;
                uzduotis += "1. Kontaktas.Susitikimas: 2 ar daugiau subjektų (turi būti paminėti pvz. žmonės, šalys, įmonės) susitikimas tam tikroje vietoje fiziškai (akis į akį). Įeina pokalbiai, summit'ai, konferencijos, vizitai ir kiti susitikimai. Tam, kad sakinys atitiktų įvykį: Kontaktas.Susitikimas, jame turi būti aiškiai nusakyta, kad susitikimas kažkur vyksta fiziškai t.y. žmonės kažkur susitiko akis į akį. Pvz. \"GM kalbasi su Chrysler dėl Jeep įsigyjimo\" - nelaikytina susitikimo įvykiu." + Environment.NewLine;
                uzduotis += "2. Kontaktas.Telefonu-Rašytinis: 2 ar daugiau žmonių (turi būti paminėti) sukontaktuoja telefonu ar raštu (pvz. el. paštu) nuotoliu be fizinio susitikimo. \"Asmuo pasakė žurnalistams\" arba \"išleido pranešimą spaudai\" nėra šis įvykis." + Environment.NewLine + Environment.NewLine;
                uzduotis += "Geri pavyzdžiai:" + Environment.NewLine + Environment.NewLine;
                uzduotis += "Įvestis: Bušas ir Putinas šią savaitę susitiko aptarti reikalus dėl Čėčėnijos." + Environment.NewLine;
                uzduotis += "Išvestis: [{\"Trigeris\":\"susitiko\",\"Laikas\":\"šią savaitę\",\"Tipas\":\"Kontaktas.Susitikimas\"}]" + Environment.NewLine + Environment.NewLine;
                uzduotis += "Įvestis: Džonas išsiuntė el. laišką Džeinei." + Environment.NewLine;
                uzduotis += "Išvestis: [{\"Trigeris\":\"išsiuntė\",\"Laikas\":\"\",\"Tipas\":\"Telefonu-Rašytinis\"}]" + Environment.NewLine + Environment.NewLine;
            }
            else if (metodika == "3")
            {
                // tik rezultato isvesties pavyzdys
                uzduotis += "Tai yra šioje užduotyje pateiktų 1 iš 2 įvykių tipų ir jų laiko nustatymo užduotis. Užduoties tekstu galimai pateikiamas tik 1 įvykis. Jeigu pateikiamas tekstas yra vienas iš reikiamų atpažinti įvykių, pateikti struktūrizuotą išvestį pagal pavyzdį. Kitu atveju, pateikti atsakymą: nenustatyta." + Environment.NewLine + Environment.NewLine;
                uzduotis += "Įvykio aprašymas ir užduoties įvykių tipai" + Environment.NewLine + Environment.NewLine;
                uzduotis += "Įvykis yra vyksmas, kuriame dalyvauja jo dalyviai. Įvykis yra kažkas kas įvyksta. Įvykį taip pat galima apibūdinti kaip būsenos pokytį." + Environment.NewLine + Environment.NewLine;
                uzduotis += "1. Kontaktas.Susitikimas: 2 ar daugiau subjektų (turi būti paminėti pvz. žmonės, šalys, įmonės) susitikimas tam tikroje vietoje fiziškai (akis į akį). Įeina pokalbiai, summit'ai, konferencijos, vizitai ir kiti susitikimai. Tam, kad sakinys atitiktų įvykį: Kontaktas.Susitikimas, jame turi būti aiškiai nusakyta, kad susitikimas kažkur vyksta fiziškai t.y. žmonės kažkur susitiko akis į akį. Pvz. \"GM kalbasi su Chrysler dėl Jeep įsigyjimo\" - nelaikytina susitikimo įvykiu." + Environment.NewLine;
                uzduotis += "2. Kontaktas.Telefonu-Rašytinis: 2 ar daugiau žmonių (turi būti paminėti) sukontaktuoja telefonu ar raštu (pvz. el. paštu) nuotoliu be fizinio susitikimo. \"Asmuo pasakė žurnalistams\" arba \"išleido pranešimą spaudai\" nėra šis įvykis." + Environment.NewLine + Environment.NewLine;
                uzduotis += "Rezultato švesties pavyzdys:" + Environment.NewLine + Environment.NewLine;
                uzduotis += "Išvestis: [{\"Trigeris\":\"susitiko\",\"Laikas\":\"šią savaitę\",\"Tipas\":\"Kontaktas.Susitikimas\"}]" + Environment.NewLine + Environment.NewLine;
            }
            else if (metodika == "4")
            {
                // kaip metodika 1 tik kita temperatura
                temperatura = 1F;
                uzduotis += "Tai yra šioje užduotyje pateiktų 1 iš 2 įvykių tipų ir jų laiko nustatymo užduotis. Užduoties tekstu galimai pateikiamas tik 1 įvykis. Jeigu pateikiamas tekstas yra vienas iš reikiamų atpažinti įvykių, pateikti struktūrizuotą išvestį pagal pavyzdį. Kitu atveju, pateikti atsakymą: nenustatyta." + Environment.NewLine + Environment.NewLine;
                uzduotis += "Įvykio aprašymas ir užduoties įvykių tipai" + Environment.NewLine + Environment.NewLine;
                uzduotis += "Įvykis yra vyksmas, kuriame dalyvauja jo dalyviai. Įvykis yra kažkas kas įvyksta. Įvykį taip pat galima apibūdinti kaip būsenos pokytį." + Environment.NewLine + Environment.NewLine;
                uzduotis += "1. Kontaktas.Susitikimas: 2 ar daugiau subjektų (turi būti paminėti pvz. žmonės, šalys, įmonės) susitikimas tam tikroje vietoje fiziškai (akis į akį). Įeina pokalbiai, summit'ai, konferencijos, vizitai ir kiti susitikimai. Tam, kad sakinys atitiktų įvykį: Kontaktas.Susitikimas, jame turi būti aiškiai nusakyta, kad susitikimas kažkur vyksta fiziškai t.y. žmonės kažkur susitiko akis į akį. Pvz. \"GM kalbasi su Chrysler dėl Jeep įsigyjimo\" - nelaikytina susitikimo įvykiu." + Environment.NewLine;
                uzduotis += "2. Kontaktas.Telefonu-Rašytinis: 2 ar daugiau žmonių (turi būti paminėti) sukontaktuoja telefonu ar raštu (pvz. el. paštu) nuotoliu be fizinio susitikimo. \"Asmuo pasakė žurnalistams\" arba \"išleido pranešimą spaudai\" nėra šis įvykis." + Environment.NewLine + Environment.NewLine;
                uzduotis += "Geri pavyzdžiai:" + Environment.NewLine + Environment.NewLine;
                uzduotis += "Įvestis: Bušas ir Putinas šią savaitę susitiko aptarti reikalus dėl Čėčėnijos." + Environment.NewLine;
                uzduotis += "Išvestis: [{\"Trigeris\":\"susitiko\",\"Laikas\":\"šią savaitę\",\"Tipas\":\"Kontaktas.Susitikimas\"}]" + Environment.NewLine + Environment.NewLine;
                uzduotis += "Įvestis: Džonas išsiuntė el. laišką Džeinei." + Environment.NewLine;
                uzduotis += "Išvestis: [{\"Trigeris\":\"išsiuntė\",\"Laikas\":\"\",\"Tipas\":\"Telefonu-Rašytinis\"}]" + Environment.NewLine + Environment.NewLine;
                uzduotis += "Blogi pavyzdžiai:" + Environment.NewLine + Environment.NewLine;
                uzduotis += "Įvestis: GM jau metus kalbasi su Chrysler dėl Jeep įsigyjimo." + Environment.NewLine;
                uzduotis += "Išvestis: [{\"Trigeris\":\"kalbasi\",\"Laikas\":\"metus\",\"Tipas\":\"Kontaktas.Susitikimas\"}]" + Environment.NewLine + Environment.NewLine;
                uzduotis += "Įvestis: Prezidentas Nausėda pareiškė žurnalistas, kad kitais metais kandidatuos į prezidentus." + Environment.NewLine;
                uzduotis += "Išvestis: [{\"Trigeris\":\"pareiškė\",\"Laikas\":\"kitais metais\",\"Tipas\":\"Telefonu-Rašytinis\"}]" + Environment.NewLine + Environment.NewLine;
            }

            uzduotis += "Užduoties tekstas: " + Environment.NewLine;
            //uzduotis += "Raseinių rajone, Ariogaloje, spalio 3 dieną, mirė mažametis vaikas (2015 m.).";
            uzduotis += sakinys;

            // 1 tokenas ~ 4 angl. raides, tai cia apie iki 50 tokenu
            string rez = uzduotis.ToGPT(0.7f, OpenAI.ObjectModels.Models.Gpt_4o);

            Ivykis ivykis = new Ivykis();

            if (!rez.ToLower().Contains("nenustatyta"))
            {
                int startIndex = rez.IndexOf('[');
                int endIndex = rez.IndexOf(']');

                string dataBetweenBrackets = rez.Substring(startIndex + 1, endIndex - startIndex - 1);

                try
                {
                    ivykis = JsonConvert.DeserializeObject<Ivykis>(dataBetweenBrackets);
                }
                catch
                {
                    // anomalija gaunasi, kai sudetinis sakinys, tai isveda triguba rezultata
                    // tarsi ir teisingai dalinai


                    //MessageBox.Show("JSON konvertavimo klaida.");
                    //System.Environment.Exit(0);
                    return ivykis;
                }

                ivykis.Apimtis = sakinys;
                ivykis.Apimtis_indeksas = pradzios_indeksas.ToString(); // cia reikia perduoti
                ivykis.Apimtis_ilgis = sakinys.Length.ToString();

                if (ivykis.Laikas.IsNotNullOrEmpty())
                {
                    int laikas_index = sakinys.ToLower().IndexOf(ivykis.Laikas.ToLower());

                    if (laikas_index == -1)
                    {
                        ivykis.Laikas_indeksas = (laikas_index).ToString(); // isskaiciuoti pagla apimties pradzia
                        ivykis.Laikas_ilgis = ivykis.Laikas.Length.ToString();

                        //MessageBox.Show("Klaida 02 (laikas) anotuojant straipsnį " + straipsnio_id);
                        //System.Environment.Exit(0);

                        // gali buti 2 laikai pvz sestadieni, ir sekmadieni
                        // ir gpt pazymi juos abu bet i viena lauka ir tada negali uztagint
                    }
                }
                else
                {
                    ivykis.Laikas_indeksas = "";
                    ivykis.Laikas_ilgis = "";
                }

                if (ivykis.Trigeris.IsNotNullOrEmpty())
                {
                    int trigeris_index = sakinys.ToLower().IndexOf(ivykis.Trigeris.ToLower());


                    if (trigeris_index != -1)
                    {
                        ivykis.Trigeris_indeksas = (trigeris_index).ToString();
                        ivykis.Trigeris_ilgis = ivykis.Trigeris.Length.ToString();

                        // buna tokia anomalija, kad GPT trigeriu nustato zodi, kurio net nera sakinyje

                        //MessageBox.Show("Klaida 02 (trigeris) anotuojant straipsnį " + straipsnio_id);
                        //System.Environment.Exit(0);
                    }
                }
                else
                {
                    ivykis.Trigeris_indeksas = "";
                    ivykis.Trigeris_ilgis = "";
                }


            }

            return ivykis;

            //MessageBox.Show(string.Format("Sakinys: \n\n{0}\n\nGPT rezultatas: \n\n{1}", sakinys, rez));

        }

        string[,] ivykis_pagal_zodyna(string sakinys)
        {
            string[,] rez = new string[,]
            {
                { "", "" },
            };

            for (int i = 0; i < ivykiu_trigeriu_zodynas.GetLength(0); i++)
            {
                if (sakinys.ToLower().Contains(ivykiu_trigeriu_zodynas[i, 0].ToString().ToLower()))
                {
                    rez[0, 0] = ivykiu_trigeriu_zodynas[i, 0]; // trigeris
                    rez[0, 1] = ivykiu_trigeriu_zodynas[i, 1]; // ivykio tipas
                    return rez;
                }
            }

            return rez;
        }

        Ivykis zodyninis_annotation(string sakinys, int pradzios_indeksas, string straipsnio_id)
        {
            Ivykis ivykis = new Ivykis();

            string[,] rez = ivykis_pagal_zodyna(sakinys); // return "" arba ivykio tipa

            string trigeris = rez[0, 0];
            string ivykio_tipas = rez[0, 1];

            if (trigeris.IsNotNullOrEmpty())
            {
                ivykis.Apimtis = sakinys;
                ivykis.Apimtis_indeksas = pradzios_indeksas.ToString(); // cia reikia perduoti
                ivykis.Apimtis_ilgis = sakinys.Length.ToString();

                ivykis.Laikas = "";
                ivykis.Laikas_indeksas = "";
                ivykis.Laikas_ilgis = "";

                ivykis.Trigeris = trigeris;
                ivykis.Tipas = ivykio_tipas;
                int trigeris_index = sakinys.ToLower().IndexOf(ivykis.Trigeris.ToLower());
                if (trigeris_index != -1)
                {
                    ivykis.Trigeris_indeksas = (trigeris_index).ToString();
                    ivykis.Trigeris_ilgis = ivykis.Trigeris.Length.ToString();
                }
            }

            return ivykis;
        }

        Ivykis ml_annotation(string sakinys, int pradzios_indeksas, string straipsnio_id)
        {
            Ivykis ivykis = new Ivykis();

            // trigerio nenustato
            string ivykio_tipas = MLmodel.Predict(sakinys); // return "" arba ivykio tipa

            if (ivykio_tipas != "Ne")
            {
                ivykis.Apimtis = sakinys;
                ivykis.Apimtis_indeksas = pradzios_indeksas.ToString(); // cia reikia perduoti
                ivykis.Apimtis_ilgis = sakinys.Length.ToString();

                ivykis.Tipas = ivykio_tipas;

                ivykis.Laikas = "";
                ivykis.Laikas_indeksas = "";
                ivykis.Laikas_ilgis = "";

                ivykis.Trigeris = "";

                ivykis.Trigeris_indeksas = "";
                ivykis.Trigeris_ilgis = "";
            }

            return ivykis;
        }

        private void StraipsnisBox_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                // Get the current mouse position
                Point mousePosition = Control.MousePosition;

                // Show the ContextMenuStrip at the mouse position
                meniu.Show(mousePosition);
            }
        }

        private void NaujasIvykis_Click(object sender, EventArgs e)
        {
            // pradinis nuskaitymas
            string Text = straipsnisBox.SelectedText;
            int StartIndex = straipsnisBox.SelectionStart;
            int Length = straipsnisBox.SelectionLength;

            // tikrinti ar dalis pazymeto teksto nera su pakeista spalva

            bool redagavimas = false;
            straipsnisBox.Select(StartIndex, 1);
            Color spalvapirma = straipsnisBox.SelectionBackColor;
            if (spalvapirma != SystemColors.Control)
            {
                redagavimas = true;
            }

            for (int i = StartIndex; i < StartIndex + Length; i++)
            {
                // Set the cursor position to the position you want to check
                straipsnisBox.Select(i, 1);
                Color spalva = straipsnisBox.SelectionBackColor;

                if (redagavimas)
                {
                    if (spalva == SystemColors.Control)
                    {
                        MessageBox.Show("Pažymėta kito įvykio dalis. Turite pažymėti identiškai, jei norite redaguoti esamą.");
                        return;
                    }
                }
                else
                {
                    if (spalva != SystemColors.Control)
                    {
                        MessageBox.Show("Pažymėta kito įvykio dalis. Turite pažymėti identiškai, jei norite redaguoti esamą.");
                        return;
                    }
                }

            }

            if (redagavimas)
            {
                // jei pazymetos visos nuspalvintos patikrinti ar po ir pries ne spalvos
                // jei pradzia -1 ir pabaiga +1 ne tarpas, tai pazymetas ne pilnai sakinys
                if (StartIndex > 0)
                {
                    // Set the cursor position to the position you want to check
                    straipsnisBox.Select(StartIndex - 1, 1);
                    Color spalva = straipsnisBox.SelectionBackColor;

                    if (spalva != SystemColors.Control)
                    {
                        MessageBox.Show("Pažymėta kito įvykio dalis. Turite pažymėti identiškai, jei norite redaguoti esamą.");
                        return;
                    }
                }

                if (StartIndex + Length < straipsnisBox.Text.Length)
                {
                    // Set the cursor position to the position you want to check
                    straipsnisBox.Select(StartIndex + Length + 1, 1);
                    Color spalva = straipsnisBox.SelectionBackColor;

                    if (spalva != SystemColors.Control)
                    {
                        MessageBox.Show("Pažymėta kito įvykio dalis. Turite pažymėti identiškai, jei norite redaguoti esamą.");
                        return;
                    }
                }
            }
            else // jei ne redagavimas, tai patikra
            {
                // pradzios nutrinimas ir indeksu perskaiciavimas, jei reikia
                string trimmedTextStart = Text.TrimStart();
                if (trimmedTextStart.Length != Text.Length)
                {
                    StartIndex = StartIndex + (Text.Length - trimmedTextStart.Length);
                    Text = trimmedTextStart;
                    Length = Text.Length;
                }

                string trimmedTextEnd = Text.TrimEnd();
                if (trimmedTextEnd.Length != Text.Length)
                {
                    // start indeksas nesikeicia, tik ilgis
                    Text = trimmedTextEnd;
                    Length = Text.Length;
                }

                // pirma raide turi buti didzioji
                // gale sauktukas, arba klaustukas arba taskas
                // viduje turi nebuti tasko

                if (!char.IsUpper(Text[0]))
                {
                    // jei pirma ne didzioji tai sekanti po simbolio turi buti didzioji
                    if (!char.IsUpper(Text[1]))
                    {
                        const string message = "Pirma / antra raidė ne didžioji. Jei OK, spauskite Taip.";
                        const string caption = "Patikra";
                        var result = MessageBox.Show(message, caption,
                                                     MessageBoxButtons.YesNo,
                                                     MessageBoxIcon.Question);

                        if (result == DialogResult.No)
                            return;
                    }
                }

                // jei pradzia -1 ir pabaiga +1 ne tarpas, tai pazymetas ne pilnai sakinys
                if (StartIndex > 0)
                {
                    if (!Char.IsWhiteSpace(straipsnisBox.Text[StartIndex - 1]))
                    {
                        MessageBox.Show("Nepilnai pažymėtas sakinys.");
                        return;
                    }
                }

                if (StartIndex + Length < straipsnisBox.Text.Length)
                {
                    if (!Char.IsWhiteSpace(straipsnisBox.Text[StartIndex + Length]))
                    {
                        MessageBox.Show("Nepilnai pažymėtas sakinys.");
                        return;
                    }
                }

                string paskutinis_simbolis = Text.Substring(Length - 1, 1);

                if (paskutinis_simbolis != "." && paskutinis_simbolis != "?" && paskutinis_simbolis != "!")
                {
                    const string message = "Sakinio paskutinis simbolis ne .?! Patikrinkite ar OK, jei taip - spauskite Taip.";
                    const string caption = "Patikra";
                    var result = MessageBox.Show(message, caption,
                                                 MessageBoxButtons.YesNo,
                                                 MessageBoxIcon.Question);

                    if (result == DialogResult.No)
                        return;
                }

                if (Text.Substring(1, Length - 2).Contains("."))
                {
                    const string message = "Sakinio viduje yra .(taškas). Patikrinkite ar pažymėjote ne 2 sakinius ir jei OK, spauskite Taip.";
                    const string caption = "Patikra";
                    var result = MessageBox.Show(message, caption,
                                                 MessageBoxButtons.YesNo,
                                                 MessageBoxIcon.Question);

                    if (result == DialogResult.No)
                        return;
                }
            }

            IvykisForm langas = new IvykisForm(Text, StartIndex.ToString(), Length.ToString(), anotacijos_obj);
            langas.ShowDialog();

            if (langas.ok_click)
            {
                if (langas.naikinamos_anotacijos_id == -1)
                {
                    if (langas.redaguojamos_anotacijos_id == -1) // senas
                    {
                        anotacijos_obj.Ivykiai.Add(langas.ivykis);
                    }
                    else // redaguojamas
                    {
                        anotacijos_obj.Ivykiai[langas.redaguojamos_anotacijos_id] = langas.ivykis;
                    }

                    spalvinti_viena_anotacija(langas.ivykis);
                }
                else
                {
                    panaikinti_spalvinima_anotacijos(StartIndex, Length);
                    anotacijos_obj.Ivykiai.RemoveAt(langas.naikinamos_anotacijos_id);
                }

                issaugotianotacijasButton.Visible = true;
            }
        }

        void panaikinti_spalvinima_anotacijos(int StartIndex, int Length)
        {
            straipsnisBox.Select(StartIndex, Length);
            straipsnisBox.SelectionBackColor = SystemColors.Control;
        }

        void spalvinti_viena_anotacija(Ivykis ivykis_spalvinti)
        {
            int IvykisMentionIndeksas = ivykis_spalvinti.Apimtis_indeksas.ToInt32();
            int IvykisMentionIlgis = ivykis_spalvinti.Apimtis_ilgis.ToInt32();

            straipsnisBox.Select(IvykisMentionIndeksas, IvykisMentionIlgis);
            straipsnisBox.SelectionBackColor = Color.Yellow;

            // laiko zymejimas
            if (ivykis_spalvinti.Laikas.IsNotNullOrEmpty())
            {
                int LaikasIndeksas = IvykisMentionIndeksas + ivykis_spalvinti.Laikas_indeksas.ToInt32();
                straipsnisBox.Select(LaikasIndeksas, ivykis_spalvinti.Laikas_ilgis.ToInt32());
                straipsnisBox.SelectionBackColor = Color.Blue;
            }

            // trigerio zymejimas
            if (ivykis_spalvinti.Trigeris.IsNotNullOrEmpty())
            {
                int TrigerisIndeksas = IvykisMentionIndeksas + ivykis_spalvinti.Trigeris_indeksas.ToInt32();
                straipsnisBox.Select(TrigerisIndeksas, ivykis_spalvinti.Trigeris_ilgis.ToInt32());
                straipsnisBox.SelectionBackColor = Color.Orange;
            }
        }

        private void StraipsniaiCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            ikrauti_straipsni(null);
        }

        private void DataCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            ikrauti_straipsnius();
        }

        private void KategorijaCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            ikrauti_straipsnius();
        }

        void ikrauti_kategorijas()
        {
            //kategorijaCombo.Items.Clear();
            //string data = dataCombo.Text.ToString();

            //string[,] rez = string.Format("select distinct kategorija from ktu_articles where [data] > '{0} 00:00' and [data] < '{0} 23:59:59'", data).ToSqlSelect();
            //for (int i = 0;  i < rez.GetLength(0); i++) 
            //{
            //    kategorijaCombo.Items.Add(rez[i, 0]);
            //}
        }

        void ikrauti_datas()
        {
            dataCombo.Items.Clear();

            string[,] rez = "select distinct cast([data] as date) dat from ktu_articles order by dat desc".ToSqlSelect();
            for (int i = 0; i < rez.GetLength(0); i++)
            {
                dataCombo.Items.Add(rez[i, 0].Substring(0, 10));
            }
        }

        void ikrauti_straipsnius()
        {
            string data = dataCombo.Text.ToString();


            if (data.IsNullOrEmpty())
            {
                //MessageBox.Show("Neparinkta data.");
                return;
            }

            //string kategorija_filtras = "";
            //if (kategorija.IsNotNullOrEmpty())
            //    kategorija_filtras = string.Format("and kategorija = '{0}'", kategorija);

            straipsniaiCombo.Items.Clear();

            string[,] rez = string.Format("select cast([data] as date), pavadinimas, id from ktu_articles where cast(data as date) = '{0}' order by pavadinimas", data).ToSqlSelect();
            for (int i = 0; i < rez.GetLength(0); i++)
            {
                straipsniaiCombo.Items.Add(rez[i, 1] + "-" + rez[i, 2]);
            }

        }

        //void ikrauti_kategorijas()
        //{
        //    kategorijaCombo.Items.Clear();
        //    string[,] rez_cats = string.Format("select distinct kategorija from ktu_articles where cast(data as date) = '{0}'", data).ToSqlSelect();
        //    for (int i = 0; i < rez_cats.GetLength(0); i++)
        //    {
        //        kategorijaCombo.Items.Add(rez_cats[i, 0]);
        //    }
        //}

        void ikrauti_straipsni(string straipsnio_id)
        {
            anotacijosjsonBox.Text = "";
            issaugotianotacijasButton.Visible = false;

            string straipsnio_pavad = straipsniaiCombo.Text.ToString();

            //if (straipsnio_pavad.IsNotNullOrEmpty())
            {
                if (straipsnio_id.IsNullOrEmpty())
                {
                    string[] rez = straipsnio_pavad.Split('-');
                    ikrauto_straipsnio_id = rez[rez.GetLength(0) - 1];
                    idBox.Text = ikrauto_straipsnio_id;
                }
                else
                {
                    try
                    {
                        straipsnio_id.ToInt32();
                    }
                    catch
                    {
                        MessageBox.Show("Straipsnio ID nerastas");
                        return;
                    }

                    ikrauto_straipsnio_id = straipsnio_id;
                }

                string[,] rez2 = string.Format("select kategorija, data, pavadinimas, atnaujintas, antraste, tekstas, anotacijos, anotavimas_baigtas, anotavo_signature, [anotacijos_Gpt_4_1106_preview], straipsnis from ktu_articles where id = '{0}'", ikrauto_straipsnio_id).ToSqlSelect();

                //kategorijaCombo.SelectedIndex = kategorijaCombo.FindStringExact(rez2[0, 0]);
                dataBox.Text = rez2[0, 1];
                pavadinimasBox.Text = rez2[0, 2];
                if (rez2[0, 3].ToBoolean() == true)
                {
                    pavadinimasBox.Text += " (atnaujintas)";
                }

                // testuotju
                //straipsnisBox.Text = rez2[0, 4] + Environment.NewLine + Environment.NewLine + rez2[0, 5];
                straipsnisBox.Text = rez2[0, 10];

                kategorijaBox.Text = rez2[0, 0];
                string straipsnio_etalonines_anotacijos = rez2[0, 6];
                //straipsnio_anotacijos_gpt = rez2[0, 9];
                baigtasCheck.Checked = rez2[0, 7].ToBoolean();
                anotuotojasBox.Text = rez2[0, 8];

                if (rez2[0, 6].IsNotNullOrEmpty()) // straipsnio anotacijos
                {
                    //gptanotavimasButton.Visible = false;
                    gptanotacijuikrovimasButton.Visible = true;
                    zodyniniuanotacijuikrovimasButton.Visible = true;
                    mlanotacijosButton.Visible = true;
                }

                ikrauti_anotacijas(straipsnio_etalonines_anotacijos);
            }
        }

        void ikrauti_anotacijas(string straipsnio_anotacijos)
        {
            if (straipsnio_anotacijos.IsNullOrEmpty() || straipsnio_anotacijos.Length == 14)
            {
                anotacijos_obj = new Anotacijos();
                anotacijos_obj.Ivykiai = new List<Ivykis> { };
            }
            else
            {
                if (straipsnio_anotacijos.Length > 25)
                {
                    anotacijos_obj = JsonConvert.DeserializeObject<Anotacijos>(straipsnio_anotacijos);
                    spalvinti_anotacijas();
                }
            }

            anotacijosjsonBox.Text = straipsnio_anotacijos;
        }

        bool yra_ivykis(string sakinys, string indeksas, Anotacijos ivykiai)
        {
            foreach (Ivykis ivykis in ivykiai.Ivykiai)
            {
                if (ivykis.Apimtis == sakinys || ivykis.Apimtis_indeksas == indeksas)
                    return true;
            }

            return false;
        }

        void ivertinimas_visu(string metodika)
        {
            string komanda = "";

            if (metodika == "1")
            {
                komanda = "select id from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and anotacijos_Gpt_4_1106_preview is not null";
            }
            if (metodika == "2")
            {
                komanda = "select id from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and [anotacijos_gpt_2] is not null";
            }
            if (metodika == "3")
            {
                komanda = "select id from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and [anotacijos_gpt_3] is not null";
            }
            if (metodika == "4")
            {
                komanda = "select id from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and [anotacijos_gpt_4] is not null";
            }
            if (metodika == "zod")
            {
                komanda = "select id from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and [anotacijos_zodyno] is not null";
            }
            if (metodika == "ml")
            {
                komanda = "select id from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and [anotacijos_ml] is not null";
            }
            if (metodika == "mlv2")
            {
                komanda = "select id from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and [anotacijos_ml_v2] is not null";
            }
            if (metodika == "new")
            {
                komanda = "select id from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and [anotacijos_gpt-4o-2024-05-13_0F] is not null";
            }
            if (metodika == "new_1")
            {
                komanda = "select id from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and [anotacijos_gpt-4o-2024-05-13_1F] is not null";
            }
            if (metodika == "new_0")
            {
                komanda = "select id from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and [anotacijos_gpt-4o-2024-05-13] is not null";
            }
            if (metodika == "gptmini")
            {
                komanda = "select id from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and [anotacijos_gptmini] is not null";
            }
            if (metodika == "gpt4o")
            {
                komanda = "select id from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and [anotacijos_gpt4o] is not null";
            }
            if (metodika == "geminiflash")
            {
                komanda = "select id from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and [anotacijos_geminiflash] is not null";
            }
            if (metodika == "geminipro")
            {
                komanda = "select id from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and [anotacijos_geminipro] is not null";
            }
            if (metodika == "combined1" || metodika == "combined2")
            {
                komanda = "select id from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and [anotacijos_geminipro] is not null";
            }
            if (metodika == "gptmini2")
            {
                komanda = "select id from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and [anotacijos_gptmini2] is not null";
            }
            if (metodika == "geminipro2")
            {
                komanda = "select id from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and [anotacijos_geminipro2] is not null";
            }
            if (metodika == "geminiflash2")
            {
                komanda = "select id from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and [anotacijos_geminiflash2] is not null";
            }
            if (metodika == "gpt4o2")
            {
                komanda = "select id from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and [anotacijos_gpt4o2] is not null";
            }
            else // extended experiment. FOR sme1-5/ft1-5/lr1-5
            {
                komanda = string.Format("select id from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and {0} is not null", metodika);
            }

            string[,] rez = komanda.ToSqlSelect();
            // and anotavo_signature = 'J'

            double total_sentences = 0;
            double total_symbols = 0;

            double true_positives = 0; // teisingai nustatyta, kad ivykis
            double true_negatives = 0; // teisingai nustatyta, kad nera ivykio
            double false_positives = 0; // nustatyta, kad ivykis, nors ne ivykis
            double false_negatives = 0; // nenustatyta, kad ivykis, bet ivykis

            double Accuracy = 0;
            double Precision = 0;
            double Recall = 0;
            double F1Score = 0;

            for (int i = 0; i < rez.GetLength(0); i++)
            {
                string id = rez[i, 0].ToString();

                //double old_tp = true_positives;
                //double old_tn = true_negatives;
                //double old_fp = false_positives;
                //double old_fn = false_negatives;
                //double old_tse = total_sentences;
                //double old_tsy = total_symbols;

                ivertinimas_straipsnio(id, ref Accuracy, ref Precision, ref Recall, ref F1Score,
                    ref total_sentences, ref total_symbols, ref true_positives, ref true_negatives,
                    ref false_positives, ref false_negatives, metodika);

                //total_sentences += old_tse;
                //total_symbols += old_tsy;

                //true_positives += old_tp;
                //true_negatives += old_tn;
                //false_positives += old_fp;
                //false_negatives += old_fn;
            }

            // einama per visus sakinius. kiekvienam sakiniui ziurima ar yra etalone ir ar gpt vertinime.
            // kolkas ziurima tik ar pats ivykis teisingai atpazintas

            //double Accuracy = ((true_positives + true_negatives) / total_sentences * 100).RoundDoubleToDouble(2); // %
            //double Precision = (true_positives / (true_positives + false_positives) * 100).RoundDoubleToDouble(2); // %
            //double Recall = (true_positives / (true_positives + false_negatives) * 100).RoundDoubleToDouble(2); // %
            //double F1Score = (2 * (Precision * Recall) / (Precision + Recall)).RoundDoubleToDouble(2); // %

            MessageBox.Show(metodika + "\n\n" + string.Format("Accuracy (TP+TN/Sentences): {0}%\nPrecision (TP/Total classified positive): {1}%\nRecall (): {2}%\nF1Score (Precision recall harmon): {3}%\n\nViso sakinių: {4}\nViso simbolių: {5}",
                Accuracy.ToString(), Precision.ToString(), Recall.ToString(), F1Score.ToString(), total_sentences, total_symbols));
        }

        void ivertinimas_straipsnio(string id,
            ref double Accuracy, ref double Precision, ref double Recall, ref double F1Score,
            ref double total_sentences, ref double total_symbols,
            ref double true_positives, ref double true_negatives, ref double false_positives, ref double false_negatives,
            string metodika)
        {
            // algoritmas: imamos etaloninis ir modelio anotacijos, anotacijos is json i lista paverciamos
            // tuomet einama per kiekviena sakini

            string komanda = "";

            if (metodika == "1")
                komanda = ("select antraste, tekstas, anotacijos, anotacijos_Gpt_4_1106_preview, straipsnis from [ktu_articles] where id = " + id);
            else if (metodika == "2")
                komanda = ("select antraste, tekstas, anotacijos, [anotacijos_gpt_2], straipsnis from [ktu_articles] where id = " + id);
            else if (metodika == "3")
                komanda = ("select antraste, tekstas, anotacijos, [anotacijos_gpt_3], straipsnis from [ktu_articles] where id = " + id);
            else if (metodika == "4")
                komanda = ("select antraste, tekstas, anotacijos, [anotacijos_gpt_4], straipsnis from [ktu_articles] where id = " + id);
            else if (metodika == "zod")
                komanda = ("select antraste, tekstas, anotacijos, [anotacijos_zodyno], straipsnis from [ktu_articles] where id = " + id);
            else if (metodika == "ml")
                komanda = ("select antraste, tekstas, anotacijos, [anotacijos_ml], straipsnis from [ktu_articles] where id = " + id);
            else if (metodika == "mlv2")
                komanda = ("select antraste, tekstas, anotacijos, [anotacijos_ml_v2], straipsnis from [ktu_articles] where id = " + id);
            else if (metodika == "new")
                komanda = ("select antraste, tekstas, anotacijos, [anotacijos_gpt-4o-2024-05-13_0F], straipsnis from [ktu_articles] where id = " + id);
            else if (metodika == "new_1")
                komanda = ("select antraste, tekstas, anotacijos, [anotacijos_gpt-4o-2024-05-13_1F], straipsnis from [ktu_articles] where id = " + id);
            else if (metodika == "new_0")
                komanda = ("select antraste, tekstas, anotacijos, [anotacijos_gpt-4o-2024-05-13], straipsnis from [ktu_articles] where id = " + id);
            if (metodika == "gptmini")
            {
                komanda = ("select antraste, tekstas, anotacijos, [anotacijos_gptmini], straipsnis from [ktu_articles] where id = " + id);
            }
            if (metodika == "gpt4o")
            {
                komanda = ("select antraste, tekstas, anotacijos, [anotacijos_gpt4o], straipsnis from [ktu_articles] where id = " + id);
            }
            if (metodika == "geminiflash")
            {
                komanda = ("select antraste, tekstas, anotacijos, [anotacijos_geminiflash], straipsnis from [ktu_articles] where id = " + id);
            }
            if (metodika == "geminipro")
            {
                komanda = ("select antraste, tekstas, anotacijos, [anotacijos_geminipro], straipsnis from [ktu_articles] where id = " + id);
            }
            if (metodika == "combined1" || metodika == "combined2")
            {
                komanda = ("select antraste, tekstas, anotacijos, [anotacijos_geminipro], straipsnis, [anotacijos_gpt4o] from [ktu_articles] where id = " + id);
            }
            if (metodika == "gptmini2")
            {
                komanda = ("select antraste, tekstas, anotacijos, [anotacijos_gptmini2], straipsnis, [anotacijos_gpt4o] from [ktu_articles] where id = " + id);
            }
            if (metodika == "geminipro2")
            {
                komanda = ("select antraste, tekstas, anotacijos, [anotacijos_geminipro2], straipsnis, [anotacijos_gpt4o] from [ktu_articles] where id = " + id);
            }
            if (metodika == "geminiflash2")
            {
                komanda = ("select antraste, tekstas, anotacijos, [anotacijos_geminiflash2], straipsnis, [anotacijos_gpt4o] from [ktu_articles] where id = " + id);
            }
            if (metodika == "gpt4o2")
            {
                komanda = ("select antraste, tekstas, anotacijos, [anotacijos_gpt4o2], straipsnis, [anotacijos_gpt4o] from [ktu_articles] where id = " + id);
            }
            else // extended experiment. FOR sme 3-5/ft1-5/lr1-5
            {
                komanda = string.Format("select antraste, tekstas, anotacijos, {0}, straipsnis, {0} from [ktu_articles] where id = '{1}'", metodika, id);
            }

            string[,] rez = komanda.ToSqlSelect();

            // jeigu ne taip, o tiesiai tai pasimeta indeksas
            //straipsnisBox.Text = rez[0, 0] + Environment.NewLine + Environment.NewLine + rez[0, 1];
            string tekstas = rez[0, 4];

            string etalonas_json = rez[0, 2];

            string llm_json = rez[0, 3];
            string llm_json2 = rez[0, 5]; // combined dvieju modeliu

            //total_sentences = 0;
            //total_symbols = 0;
            //true_positives = 0; // teisingai nustatyta, kad ivykis
            //true_negatives = 0; // teisingai nustatyta, kad nera ivykio
            //false_positives = 0; // nustatyta, kad ivykis, nors ne ivykis
            //false_negatives = 0; // nenustatyta, kad ivykis, bet ivykis

            Anotacijos etalonines_anotacijos = JsonConvert.DeserializeObject<Anotacijos>(etalonas_json);
            Anotacijos llm_anotacijos = JsonConvert.DeserializeObject<Anotacijos>(llm_json);
            Anotacijos llm_anotacijos2 = JsonConvert.DeserializeObject<Anotacijos>(llm_json2);

            // einama per kiekviena sakini ir vertinama
            var props = new Properties();
            props.setProperty("annotators", "tokenize,ssplit");
            var pipeline = new StanfordCoreNLP(props);
            var annotation = new Annotation(tekstas);
            pipeline.annotate(annotation);
            var sentences = annotation.get(typeof(CoreAnnotations.SentencesAnnotation)); // cia buvo fixas
            foreach (var sentence in sentences as ArrayList)
            {
                total_sentences++;

                // skainio nustatymas
                var sentenceAnnotation = sentence as Annotation;
                var sakinys = sentenceAnnotation.toString();

                total_symbols += sakinys.Length;

                // sakinio indekso nustatymas
                var startOffsetObj = sentenceAnnotation.get(typeof(CoreAnnotations.CharacterOffsetBeginAnnotation)) as java.lang.Integer;
                string indeksas = startOffsetObj.intValue().ToString();

                bool yra_etalone = yra_ivykis(sakinys, indeksas, etalonines_anotacijos);

                if (yra_etalone)
                    total_events_annotated++;

                bool yra_llmanotacijose = yra_ivykis(sakinys, indeksas, llm_anotacijos);

                // tik combines1/combined2
                if (metodika == "combined1")
                {
                    bool yra_llmanotacijose2 = yra_ivykis(sakinys, indeksas, llm_anotacijos2);
                    if (yra_llmanotacijose && yra_llmanotacijose2)
                        yra_llmanotacijose = true;
                    else
                        yra_llmanotacijose = false;
                }
                else if (metodika == "combined2")
                {
                    bool yra_llmanotacijose2 = yra_ivykis(sakinys, indeksas, llm_anotacijos2);
                    if (yra_llmanotacijose || yra_llmanotacijose2)
                        yra_llmanotacijose = true;
                    else
                        yra_llmanotacijose = false;
                }

                if (yra_etalone && yra_llmanotacijose)
                {
                    true_positives++; // teisingai, kad ivykis
                }
                else if (!yra_etalone && !yra_llmanotacijose)
                {
                    true_negatives++; // teisingai, kad ne ivykis
                }
                else if (!yra_etalone && yra_llmanotacijose)
                {
                    false_positives++; // neteisingai, atpazino, kad ivykis, nors ne
                }
                else if (yra_etalone && !yra_llmanotacijose)
                {
                    false_negatives++; // neteisingai, netpazino ivykio
                }

                else
                {
                    MessageBox.Show("Klaida 01");
                }
            }

            // einama per visus sakinius. kiekvienam sakiniui ziurima ar yra etalone ir ar gpt vertinime.
            // kolkas ziurima tik ar pats ivykis teisingai atpazintas

            Accuracy = ((true_positives + true_negatives) / total_sentences * 100).RoundDoubleToDouble(2); // %
            Precision = (true_positives / (true_positives + false_positives) * 100).RoundDoubleToDouble(2); // %
            Recall = (true_positives / (true_positives + false_negatives) * 100).RoundDoubleToDouble(2); // %
            F1Score = (2 * (Precision * Recall) / (Precision + Recall)).RoundDoubleToDouble(2); // %
        }

        void straipsnio_spalvinimo_nuemimas()
        {
            straipsnisBox.Select(0, straipsnisBox.Text.Length);
            straipsnisBox.SelectionBackColor = SystemColors.Control;

            //ikrauti_anotacijas(straipsnio_anotacijos_gpt);
        }

        void spalvinti_anotacijas()
        {
            int count = anotacijos_obj.Ivykiai.Count;
            for (int i = 0; i < count; i++)
            {
                int IvykisMentionIndeksas = anotacijos_obj.Ivykiai[i].Apimtis_indeksas.ToInt32();
                int IvykisMentionIlgis = anotacijos_obj.Ivykiai[i].Apimtis_ilgis.ToInt32();

                straipsnisBox.Select(IvykisMentionIndeksas, IvykisMentionIlgis);
                straipsnisBox.SelectionBackColor = Color.Yellow;

                // laiko zymejimas
                if (anotacijos_obj.Ivykiai[i].Laikas.IsNotNullOrEmpty())
                {
                    int LaikasIndeksas = IvykisMentionIndeksas + anotacijos_obj.Ivykiai[i].Laikas_indeksas.ToInt32();
                    straipsnisBox.Select(LaikasIndeksas, anotacijos_obj.Ivykiai[i].Laikas_ilgis.ToInt32());
                    straipsnisBox.SelectionBackColor = Color.Blue;
                }

                // trigerio zymejimas
                if (anotacijos_obj.Ivykiai[i].Trigeris.IsNotNullOrEmpty())
                {
                    int TrigerisIndeksas = IvykisMentionIndeksas + anotacijos_obj.Ivykiai[i].Trigeris_indeksas.ToInt32();
                    straipsnisBox.Select(TrigerisIndeksas, anotacijos_obj.Ivykiai[i].Trigeris_ilgis.ToInt32());
                    straipsnisBox.SelectionBackColor = Color.Orange;
                }
            }
        }

        private void Tekstynas_Load(object sender, EventArgs e)
        {

        }

        void llm_automatinis_suanotavimas(string tekstas, string id, string metodika, string db_column, string llm)
        {
            // tekstas segmentuojamas i sakinius
            var props = new Properties();
            props.setProperty("annotators", "tokenize,ssplit");
            var pipeline = new StanfordCoreNLP(props);
            var annotation = new Annotation(tekstas);
            pipeline.annotate(annotation);
            var sentences = annotation.get(typeof(CoreAnnotations.SentencesAnnotation));
            Anotacijos LLManot = new Anotacijos();
            LLManot.Ivykiai = new List<Ivykis> { };

            // einama per kiekviena sakini ir vertinama
            foreach (var sentence in sentences as ArrayList)
            {
                var sentenceAnnotation = sentence as Annotation;
                var sentenceText = sentenceAnnotation.toString();
                var startOffsetObj = sentenceAnnotation.get(typeof(CoreAnnotations.CharacterOffsetBeginAnnotation)) as java.lang.Integer;
                int startOffset = startOffsetObj.intValue();

                // cia esme
                Ivykis LLMivykis = LLM_annotation_new_framework(sentenceText, startOffset, id, db_column, llm);

                if (LLMivykis.Apimtis != null)
                    LLManot.Ivykiai.Add(LLMivykis);

                // 1. musu anotacijos gavimas
                // 2. gpt anotacijos gavimas
                // 3. palyginimas
            }


            string anotacija_json_string = JsonConvert.SerializeObject(LLManot);

            string.Format("update ktu_articles set [{2}] = '{0}' where id = '{1}'",
                anotacija_json_string, id, db_column).ToSqlInsertUpdateDelete();

            //if (metodika == "1")
            //{
            //    string.Format("update ktu_articles set [anotacijos_Gpt_4_1106_preview] = '{0}' where id = '{1}'",
            //        anotacija_json_string, id).ToSqlInsertUpdateDelete();
            //}
            //else if (metodika == "2")
            //{
            //    string.Format("update ktu_articles set [anotacijos_gpt_2] = '{0}' where id = '{1}'",
            //        anotacija_json_string, id).ToSqlInsertUpdateDelete();
            //}
            //else if (metodika == "3")
            //{
            //    string.Format("update ktu_articles set [anotacijos_gpt_3] = '{0}' where id = '{1}'",
            //        anotacija_json_string, id).ToSqlInsertUpdateDelete();
            //}
            //else if (metodika == "4")
            //{
            //    string.Format("update ktu_articles set [anotacijos_gpt_4] = '{0}' where id = '{1}'",
            //        anotacija_json_string, id).ToSqlInsertUpdateDelete();
            //}

            gptanotacijuikrovimasButton.Visible = true;
            gptanotavimasButton.Visible = false;

            //MessageBox.Show("GPT anotavimas baigtas.");
        }

        void ml_automatinis_suanotavimas(string tekstas, string id, string combo)
        {
            // version varies sme1-5/ft1-5/lr-1-5

            // tekstas segmented into tokens (sentences)

            var props = new Properties();
            props.setProperty("annotators", "tokenize,ssplit");
            var pipeline = new StanfordCoreNLP(props);

            var annotation = new Annotation(tekstas);
            pipeline.annotate(annotation);

            var sentences = annotation.get(typeof(CoreAnnotations.SentencesAnnotation));

            Anotacijos ml_anot = new Anotacijos();
            ml_anot.Ivykiai = new List<Ivykis> { };

            // iterrate through sentences

            foreach (var sentence in sentences as ArrayList)
            {
                var sentenceAnnotation = sentence as Annotation;
                var sentenceText = sentenceAnnotation.toString();

                var startOffsetObj = sentenceAnnotation.get(typeof(CoreAnnotations.CharacterOffsetBeginAnnotation)) as java.lang.Integer;
                int startOffset = startOffsetObj.intValue();

                // just use previously loaded model
                Ivykis ml_ivykis = ml_annotation(sentenceText, startOffset, id);

                if (ml_ivykis.Apimtis != null)
                    ml_anot.Ivykiai.Add(ml_ivykis);
            }

            string anotacija_json_string = JsonConvert.SerializeObject(ml_anot);

            string.Format("update ktu_articles set {2} = '{0}' where id = '{1}'",
                anotacija_json_string, id, combo).ToSqlInsertUpdateDelete();

            zodyniniuanotacijuikrovimasButton.Visible = true;
            zodyninisanotavimasButton.Visible = false;
        }

        void zodyninis_automatinis_suanotavimas(string tekstas, string id)
        {
            // tekstas segmentuojamas i sakinius

            var props = new Properties();
            props.setProperty("annotators", "tokenize,ssplit");
            var pipeline = new StanfordCoreNLP(props);

            var annotation = new Annotation(tekstas);
            pipeline.annotate(annotation);

            var sentences = annotation.get(typeof(CoreAnnotations.SentencesAnnotation));

            Anotacijos zodyninis_anot = new Anotacijos();
            zodyninis_anot.Ivykiai = new List<Ivykis> { };

            // einama per kiekviena sakini ir vertinama

            foreach (var sentence in sentences as ArrayList)
            {
                var sentenceAnnotation = sentence as Annotation;
                var sentenceText = sentenceAnnotation.toString();

                var startOffsetObj = sentenceAnnotation.get(typeof(CoreAnnotations.CharacterOffsetBeginAnnotation)) as java.lang.Integer;
                int startOffset = startOffsetObj.intValue();

                Ivykis zodyninis_ivykis = zodyninis_annotation(sentenceText, startOffset, id);

                if (zodyninis_ivykis.Apimtis != null)
                    zodyninis_anot.Ivykiai.Add(zodyninis_ivykis);
            }

            string anotacija_json_string = JsonConvert.SerializeObject(zodyninis_anot);

            string.Format("update ktu_articles set anotacijos_zodyno = '{0}' where id = '{1}'",
                anotacija_json_string, id).ToSqlInsertUpdateDelete();

            zodyniniuanotacijuikrovimasButton.Visible = true;
            zodyninisanotavimasButton.Visible = false;

            //MessageBox.Show("GPT anotavimas baigtas.");
        }

        bool metodikos_irasymo_tikrinimas_passed()
        {
            try
            {
                if (metodikaBox.Text.ToString() != "zod" && metodikaBox.Text.ToString() != "ml")
                {
                    int i = metodikaBox.Text.ToString().ToInt32();
                    if (i < 0 || i > 4)
                    {
                        throw new InvalidOperationException("Blogai įrašyta metodika!");

                        //return false;
                    }
                }
            }
            catch
            {
                MessageBox.Show("Neįrašyta metodika 1-4, zod.");

                return false;
            }

            return true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //string metodika = metodikaBox.Text.ToString();

            //if (!metodikos_irasymo_tikrinimas_passed())
            //    return;

            //string max_id = "9999"; // ~20 straipsniu

            //string rezas = "Labas, kuo galetum padeti?".ToGPTSync(2000, 0F);

            // gemini flash: 15 RPM and 1,500 RPD, reiskia 4s waitint

            string db_column = "anotacijos_gpt4o2"; // anotacijos_gptmini, anotacijos_geminiflash
            string llm = "gpt"; // gpt, gemini

            string komanda = string.Format("select id, straipsnis from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and [{0}] is null", db_column);

            //if (metodika == "1")
            //    komanda = "select id, antraste, tekstas, straipsnis from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and anotacijos_Gpt_4_1106_preview is null and id < " + max_id;
            //else if (metodika == "2")
            //    komanda = "select id, antraste, tekstas, straipsnis from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and anotacijos_gpt_2 is null and id < " + max_id;
            //else if (metodika == "3")
            //    komanda = "select id, antraste, tekstas, straipsnis from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and anotacijos_gpt_3 is null and id < " + max_id;
            //else if (metodika == "4")
            //    komanda = "select id, antraste, tekstas, straipsnis from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and anotacijos_gpt_4 is null and id < " + max_id;


            string[,] rez = komanda.ToSqlSelect();

            // einama per visus straipsnius vertintinus
            for (int i = 0; i < rez.GetLength(0); i++)
            {
                string id = rez[i, 0].ToString();

                // jeigu ne taip, o tiesiai tai pasimeta indeksas
                //straipsnisBox.Text = rez[0, 1] + Environment.NewLine + Environment.NewLine + rez[0, 2];
                string straipsnis = rez[i, 1];

                llm_automatinis_suanotavimas(straipsnis, id, "new", db_column, llm);
            }

            MessageBox.Show("Automatinis LLM anotavimas baigtas.");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string anotacija_json_string = JsonConvert.SerializeObject(anotacijos_obj);

            string.Format("update ktu_articles set anotacijos = '{0}', anotavo_signature = '{2}', anotavimas_baigtas = '{3}' where id = '{1}'",
                anotacija_json_string, ikrauto_straipsnio_id, "", baigtasCheck.Checked.BoolToInt()).ToSqlInsertUpdateDelete();

            issaugotianotacijasButton.Visible = false;
            anotacijosjsonBox.Text = anotacija_json_string;
        }

        private void gptanotacijuikrovimasButton_Click(object sender, EventArgs e)
        {
            straipsnio_spalvinimo_nuemimas();

            string[,] rez = ("select [anotacijos_gpt-4o-2024-05-13] from ktu_articles where id = " + ikrauto_straipsnio_id).ToSqlSelect();

            string gpt_anotacijos = rez[0, 0];

            ikrauti_anotacijas(gpt_anotacijos);

            mlanotacijosButton.Visible = true;
            etaloniniuanotacijuikrovimasButton.Visible = true;
            gptanotacijuikrovimasButton.Visible = false;
            zodyniniuanotacijuikrovimasButton.Visible = true;
        }

        private void ivertinimasButton_Click(object sender, EventArgs e)
        {
            //string metodika = metodikaBox.Text.ToString();

            //if (!metodikos_irasymo_tikrinimas_passed())
            //    return;

            // string metodika = "gpt4o2"; // gptmini, gpt4o, geminiflash, geminipro, combined1(and), combined2(or)
            for (int i = 1; i < 6; i++)
            {
                string metodika = "lr" + i.ToString();

                ivertinimas_visu(metodika);

                MessageBox.Show(metodika + "\n\n" + total_events_annotated.ToString());
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string metodika = metodikaBox.Text.ToString();

            if (!metodikos_irasymo_tikrinimas_passed())
                return;

            if (straipsnisBox.Text.ToString().IsNotNullOrEmpty())
            {
                double Accuracy = 0;
                double Precision = 0;
                double Recall = 0;
                double F1Score = 0;
                double total_sentences = 0;
                double total_symbols = 0;

                double notused1 = 0;
                double notused2 = 0;
                double notused3 = 0;
                double notused4 = 0;

                ivertinimas_straipsnio(ikrauto_straipsnio_id, ref Accuracy, ref Precision, ref Recall, ref F1Score,
                    ref total_sentences, ref total_symbols, ref notused1, ref notused2, ref notused3, ref notused4, metodika);

                MessageBox.Show(string.Format("Accuracy: {0}%\nPrecision: {1}%\nRecall: {2}%\nF1Score: {3}%\n\nViso sakinių: {4}\nViso simbolių: {5}",
    Accuracy.ToString(), Precision.ToString(), Recall.ToString(), F1Score.ToString(), total_sentences, total_symbols));


            }
            else
                MessageBox.Show("Straipsnis neįkrautas.");
        }

        private void etaloniniuanotacijuikrovimasButton_Click(object sender, EventArgs e)
        {
            straipsnio_spalvinimo_nuemimas();

            string[,] rez = ("select anotacijos from ktu_articles where id = " + ikrauto_straipsnio_id).ToSqlSelect();

            string anotacijos = rez[0, 0];

            ikrauti_anotacijas(anotacijos);

            mlanotacijosButton.Visible = true;
            etaloniniuanotacijuikrovimasButton.Visible = false;
            gptanotacijuikrovimasButton.Visible = true;
            zodyniniuanotacijuikrovimasButton.Visible = true;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            string[,] rez = "select id, antraste, tekstas from ktu_articles".ToSqlSelect();

            for (int i = 0; i < rez.GetLength(0); i++)
            {
                string tekstas = rez[i, 1] + "\n\n" + rez[i, 2];
                string id = rez[i, 0];

                string.Format("update ktu_articles set straipsnis = '{0}' where id = '{1}'", tekstas, id).ToSqlInsertUpdateDelete();
            }
        }

        private void ivykiaiForm_Load(object sender, EventArgs e)
        {

        }

        void training_data_sudarymas_is_etaloniniu_anotaciju()
        {
            string[,] rez = "select anotacijos, id, tekstas from ktu_articles where anotavimas_baigtas = 1 and anotacijos is not null".ToSqlSelect();

            // einama per visus straipsnius
            for (int i = 0; i < rez.GetLength(0); i++)
            {
                // straipsnio json anotacijos
                string straipsnio_anotacijos = rez[i, 0];
                //string straipsnio_id = rez[i, 1];
                string straipsnio_tekstas = rez[i, 2];

                var props = new Properties();
                props.setProperty("annotators", "tokenize,ssplit");
                var pipeline = new StanfordCoreNLP(props);
                var annotation = new Annotation(straipsnio_tekstas);
                pipeline.annotate(annotation);
                var sentences = annotation.get(typeof(CoreAnnotations.SentencesAnnotation));

                // sudedami neanotuoti sakiniai
                foreach (var sentence in sentences as ArrayList)
                {
                    string sakinys = sentence.ToString();

                    if (!straipsnio_anotacijos.Contains(sakinys))
                    {
                        string.Format("insert into ktu_trigeriuzodynas (sakinys) values ('{0}')", sakinys).ToSqlInsertUpdateDelete();
                    }
                }

                // sudedami anotuoti sakiniai
                if (straipsnio_anotacijos.Length > 25)
                {
                    Anotacijos anotacijos_obj2 = new Anotacijos();
                    anotacijos_obj2.Ivykiai = new List<Ivykis> { };
                    anotacijos_obj2 = JsonConvert.DeserializeObject<Anotacijos>(straipsnio_anotacijos);

                    for (int j = 0; j < anotacijos_obj2.Ivykiai.Count; j++)
                    {
                        string.Format("insert into ktu_trigeriuzodynas (sakinys, ivykio_tipas, trigeris) values ('{0}','{1}','{2}')", anotacijos_obj2.Ivykiai[j].Apimtis, anotacijos_obj2.Ivykiai[j].Tipas, anotacijos_obj2.Ivykiai[j].Trigeris).ToSqlInsertUpdateDelete();
                    }
                }

            }

        }

        void training_data_sudarymas_is_gpt_pavyzdziu()
        {
            // paprasyti pavyzdziu, kai kazkoks trigeris pasiekia 10vnt itraukti i nereikalingu sarasa
            // paskui prasyti blogu pavyzdziu
        }

        // 1k ~2eur su gpt-mini
        void gpt_dataset_good_examples_v2()
        {
            // praleidus su 50 iteraciju rezultatai:
            // 355 ivykiai, 2ct, tai 56ct = 10k ivykiu
            // tai reikia 50x28 iteraciju = 1400
            // turime zodziu statistika: 11k, bet galetu buti ir 78k
            // 3,3k = 21ct

            string komanda_zodziai = "select word from ktu_words";
            string[,] zodziai = komanda_zodziai.ToSqlSelect();
            // Regex pattern to find text inside square brackets
            string pattern = @"\[(.*?)\]";

            for (int x = 51; x < 1410; x++)
            {
                Console.WriteLine(x);
                float temperatura = 0.7F; // o gal reikia cia padidinti kuryba?

                string[,] trigeriai = "select * from (select count(id) cnt, trigeris from [ktu_gpt_training_data] where v2 = 1 group by trigeris) a where cnt > 4".ToSqlSelect();
                string nereikalingi_trigeriai = "";

                if (trigeriai.GetLength(0) > 0)
                {
                    for (int i = 0; i < trigeriai.GetLength(0); i++)
                    {
                        nereikalingi_trigeriai += trigeriai[i, 1] + ", ";
                    }
                }

                string uzduotis = "";

                // pavyzdzio uzklausa
                uzduotis += "Tai yra sakinių, kurie atitiktų aprašytam 1 arba 2 įvykių tipui sudarymo užduotis. Kiekvienam sudarytam sakiniui nurodyti ir trigerį. Išvesti PRIVALOMAI pateikti formatu kaip nurodyta pavyzdyje." + Environment.NewLine;
                uzduotis += "Sudaryti sakiniai turi turėti šį žodį: " + zodziai[x, 0] + Environment.NewLine;
                if (trigeriai.GetLength(0) > 0)
                    uzduotis += "Sudaryti sakiniai turi neturėti šių žodžių: " + nereikalingi_trigeriai + Environment.NewLine;
                uzduotis += "Įvykio aprašymas ir užduoties įvykių tipai" + Environment.NewLine;
                uzduotis += "Įvykis yra vyksmas, kuriame dalyvauja jo dalyviai. Įvykis yra kažkas kas įvyksta. Įvykį taip pat galima apibūdinti kaip būsenos pokytį." + Environment.NewLine;
                uzduotis += "1.Kontaktas.Susitikimas: 2 ar daugiau subjektų(turi būti paminėti pvz.žmonės, šalys, įmonės) susitikimas tam tikroje vietoje fiziškai(akis į akį).Įeina pokalbiai, summit'ai, konferencijos, vizitai ir kiti susitikimai. Tam, kad sakinys atitiktų įvykį: Kontaktas.Susitikimas, jame turi būti aiškiai nusakyta, kad susitikimas kažkur vyksta fiziškai t.y. žmonės kažkur susitiko akis į akį. Pvz. \"GM kalbasi su Chrysler dėl Jeep įsigyjimo\" - nelaikytina susitikimo įvykiu." + Environment.NewLine;
                uzduotis += "2.Kontaktas.Telefonu - Rašytinis: 2 ar daugiau žmonių(turi būti paminėti) sukontaktuoja telefonu ar raštu(pvz.el.paštu) nuotoliu be fizinio susitikimo. \"Asmuo pasakė žurnalistams\" arba \"išleido pranešimą spaudai\" nėra šis įvykis." + Environment.NewLine;
                uzduotis += "Pavyzdys:" + Environment.NewLine;
                uzduotis += "Įvestis: Bušas ir Putinas šią savaitę susitiko aptarti reikalus dėl Čėčėnijos." + Environment.NewLine;
                uzduotis += "Išvestis: [{ \"Apimtis\":\"Bušas ir Putinas šią savaitę susitiko aptarti reikalus dėl Čėčėnijos.\",\"Trigeris\":\"susitiko\",\"Tipas\":\"Kontaktas.Susitikimas\"}]" + Environment.NewLine;

                // 1 tokenas ~ 4 angl. raides, tai cia apie iki 50 tokenu
                string rez = uzduotis.ToGPT(0.7f, OpenAI.ObjectModels.Models.Gpt_4o);

                // Find matches
                MatchCollection matches = Regex.Matches(rez, pattern);

                if (matches.Count > 1)
                {

                }

                // Print all matches
                foreach (Match match in matches)
                {
                    string dataBetweenBrackets = match.Groups[1].Value;
                    Ivykis ivykis = new Ivykis();

                    try
                    {
                        ivykis = JsonConvert.DeserializeObject<Ivykis>(dataBetweenBrackets);
                    }
                    catch
                    {
                        // anomalija gaunasi, kai sudetinis sakinys, tai isveda triguba rezultata
                        // tarsi ir teisingai dalinai


                        //MessageBox.Show("JSON konvertavimo klaida.");
                        //System.Environment.Exit(0);
                        //return ivykis;

                        //MessageBox.Show("Praleidžiama klaida: " + dataBetweenBrackets);

                        // jei buna sakinyje kabutes pvz cituoja kalba tai praleidzia
                        continue;
                    }

                    if (ivykis.Tipas != "Kontaktas.Susitikimas" && ivykis.Tipas != "Kontaktas.Telefonu - Rašytinis")
                    {

                        //x--;
                        // praleisti iteracija, blogai nustatytas tipas
                    }
                    else
                    {
                        string.Format("insert into [ktu_gpt_training_data] (Sentence, EventType, Trigeris, v2) values ('{0}','{1}','{2}','1')", ivykis.Apimtis, ivykis.Tipas, ivykis.Trigeris).ToSqlInsertUpdateDelete();
                    }
                }
            }
        }

        void gpt_dataset_good_examples_v3()
        {
            // initial parameters
            string version = "3";
            float gpt_temp = 1f;
            string gpt_model = OpenAI.ObjectModels.Models.Gpt_4o;

            // WRR rule
            string komanda_zodziai = "select word from ktu_words";
            string[,] zodziai = komanda_zodziai.ToSqlSelect();

            // Regex pattern to find text inside square brackets
            string pattern = @"\[(.*?)\]";

            for (int x = 70; x < 1410; x++) // x through zodziai (WRR)
            {
                Console.WriteLine(x);
                
                // TL, no more than 5 triggers, otherwise ask not to use
                string[,] trigeriai = string.Format("select * from (select count(id) cnt, trigeris from [ktu_gpt_training_data] where version = '{0}' group by trigeris) a where cnt > 4", version).ToSqlSelect();
                string nereikalingi_trigeriai = "";
                if (trigeriai.GetLength(0) > 0)
                {
                    for (int i = 0; i < trigeriai.GetLength(0); i++)
                    {
                        nereikalingi_trigeriai += trigeriai[i, 1] + ", ";
                    }
                }

                // prompt construction (generation request)
                string uzduotis = "";
                uzduotis += "Tai yra sakinių, kurie atitiktų aprašytam 1 arba 2 įvykių tipui sudarymo užduotis. Kiekvienam sudarytam sakiniui nurodyti ir trigerį. Išvesti PRIVALOMAI pateikti formatu kaip nurodyta pavyzdyje." + Environment.NewLine;
                uzduotis += "Sudaryti sakiniai turi turėti šį žodį: " + zodziai[x, 0] + Environment.NewLine;
                if (trigeriai.GetLength(0) > 0)
                    uzduotis += "Sudaryti sakiniai turi neturėti šių žodžių: " + nereikalingi_trigeriai + Environment.NewLine;
                uzduotis += "Įvykio aprašymas ir užduoties įvykių tipai" + Environment.NewLine;
                uzduotis += "Įvykis yra vyksmas, kuriame dalyvauja jo dalyviai. Įvykis yra kažkas kas įvyksta. Įvykį taip pat galima apibūdinti kaip būsenos pokytį." + Environment.NewLine;
                uzduotis += "1.Kontaktas.Susitikimas: 2 ar daugiau subjektų(turi būti paminėti pvz.žmonės, šalys, įmonės) susitikimas tam tikroje vietoje fiziškai(akis į akį).Įeina pokalbiai, summit'ai, konferencijos, vizitai ir kiti susitikimai. Tam, kad sakinys atitiktų įvykį: Kontaktas.Susitikimas, jame turi būti aiškiai nusakyta, kad susitikimas kažkur vyksta fiziškai t.y. žmonės kažkur susitiko akis į akį. Pvz. \"GM kalbasi su Chrysler dėl Jeep įsigyjimo\" - nelaikytina susitikimo įvykiu." + Environment.NewLine;
                uzduotis += "2.Kontaktas.Telefonu - Rašytinis: 2 ar daugiau žmonių(turi būti paminėti) sukontaktuoja telefonu ar raštu(pvz.el.paštu) nuotoliu be fizinio susitikimo. \"Asmuo pasakė žurnalistams\" arba \"išleido pranešimą spaudai\" nėra šis įvykis." + Environment.NewLine;
                uzduotis += "Pavyzdys:" + Environment.NewLine;
                uzduotis += "Įvestis: Bušas ir Putinas šią savaitę susitiko aptarti reikalus dėl Čėčėnijos." + Environment.NewLine;
                uzduotis += "Išvestis: [{ \"Apimtis\":\"Bušas ir Putinas šią savaitę susitiko aptarti reikalus dėl Čėčėnijos.\",\"Trigeris\":\"susitiko\",\"Tipas\":\"Kontaktas.Susitikimas\"}]" + Environment.NewLine;
                string rez = uzduotis.ToGPT(gpt_temp, gpt_model);

                // Find matches
                MatchCollection matches = Regex.Matches(rez, pattern);

                // Print all matches
                foreach (Match match in matches)
                {
                    string dataBetweenBrackets = match.Groups[1].Value;
                    Ivykis ivykis = new Ivykis();

                    try
                    {
                        ivykis = JsonConvert.DeserializeObject<Ivykis>(dataBetweenBrackets);
                    }
                    catch
                    {
                        // incorrect, skip iterration, no result
                        continue;
                    }

                    try
                    {
                        if (ivykis.Tipas != "Kontaktas.Susitikimas" && ivykis.Tipas != "Kontaktas.Telefonu - Rašytinis")
                        {
                            // incorrect, skip iterration, no result
                            continue;
                        }
                        else
                        {
                            // insert result
                            string.Format("insert into [ktu_gpt_training_data] (Sentence, EventType, Trigeris, version) values ('{0}','{1}','{2}','{3}')", ivykis.Apimtis, ivykis.Tipas, ivykis.Trigeris, version).ToSqlInsertUpdateDelete();
                        }
                    }
                    catch
                    {
                        // incorrect, skip iterration, no result
                        continue;
                    }

                }

            }
        }

        void gpt_dataset_good_examples_v4()
        {
            // initial parameters
            string version = "4";
            float gpt_temp = 0.7f;
            string gpt_model = OpenAI.ObjectModels.Models.Gpt_4o_mini;

            // WRR rule
            string komanda_zodziai = "select word from ktu_words";
            string[,] zodziai = komanda_zodziai.ToSqlSelect();

            // Regex pattern to find text inside square brackets
            string pattern = @"\[(.*?)\]";

            for (int x = 0; x < 105; x++) // x through zodziai (WRR)
            {
                Console.WriteLine(x);

                // TL, no more than 5 triggers, otherwise ask not to use
                string[,] trigeriai = string.Format("select * from (select count(id) cnt, trigeris from [ktu_gpt_training_data] where version = '{0}' group by trigeris) a where cnt > 4", version).ToSqlSelect();
                string nereikalingi_trigeriai = "";
                if (trigeriai.GetLength(0) > 0)
                {
                    for (int i = 0; i < trigeriai.GetLength(0); i++)
                    {
                        nereikalingi_trigeriai += trigeriai[i, 1] + ", ";
                    }
                }

                // prompt construction (generation request)
                string uzduotis = "";
                uzduotis += "Tai yra sakinių, kurie atitiktų aprašytam 1 arba 2 įvykių tipui sudarymo užduotis. Kiekvienam sudarytam sakiniui nurodyti ir trigerį. Išvesti PRIVALOMAI pateikti formatu kaip nurodyta pavyzdyje." + Environment.NewLine;
                uzduotis += "Sudaryti sakiniai turi turėti šį žodį: " + zodziai[x, 0] + Environment.NewLine;
                if (trigeriai.GetLength(0) > 0)
                    uzduotis += "Sudaryti sakiniai turi neturėti šių žodžių: " + nereikalingi_trigeriai + Environment.NewLine;
                uzduotis += "Įvykio aprašymas ir užduoties įvykių tipai" + Environment.NewLine;
                uzduotis += "Įvykis yra vyksmas, kuriame dalyvauja jo dalyviai. Įvykis yra kažkas kas įvyksta. Įvykį taip pat galima apibūdinti kaip būsenos pokytį." + Environment.NewLine;
                uzduotis += "1.Kontaktas.Susitikimas: 2 ar daugiau subjektų(turi būti paminėti pvz.žmonės, šalys, įmonės) susitikimas tam tikroje vietoje fiziškai(akis į akį).Įeina pokalbiai, summit'ai, konferencijos, vizitai ir kiti susitikimai. Tam, kad sakinys atitiktų įvykį: Kontaktas.Susitikimas, jame turi būti aiškiai nusakyta, kad susitikimas kažkur vyksta fiziškai t.y. žmonės kažkur susitiko akis į akį. Pvz. \"GM kalbasi su Chrysler dėl Jeep įsigyjimo\" - nelaikytina susitikimo įvykiu." + Environment.NewLine;
                uzduotis += "2.Kontaktas.Telefonu - Rašytinis: 2 ar daugiau žmonių(turi būti paminėti) sukontaktuoja telefonu ar raštu(pvz.el.paštu) nuotoliu be fizinio susitikimo. \"Asmuo pasakė žurnalistams\" arba \"išleido pranešimą spaudai\" nėra šis įvykis." + Environment.NewLine;
                uzduotis += "Pavyzdys:" + Environment.NewLine;
                uzduotis += "Įvestis: Bušas ir Putinas šią savaitę susitiko aptarti reikalus dėl Čėčėnijos." + Environment.NewLine;
                uzduotis += "Išvestis: [{ \"Apimtis\":\"Bušas ir Putinas šią savaitę susitiko aptarti reikalus dėl Čėčėnijos.\",\"Trigeris\":\"susitiko\",\"Tipas\":\"Kontaktas.Susitikimas\"}]" + Environment.NewLine;
                string rez = uzduotis.ToGPT(gpt_temp, gpt_model);

                // Find matches
                MatchCollection matches = Regex.Matches(rez, pattern);

                // Print all matches
                foreach (Match match in matches)
                {
                    string dataBetweenBrackets = match.Groups[1].Value;
                    Ivykis ivykis = new Ivykis();

                    try
                    {
                        ivykis = JsonConvert.DeserializeObject<Ivykis>(dataBetweenBrackets);
                    }
                    catch
                    {
                        // incorrect, skip iterration, no result
                        continue;
                    }

                    try
                    {
                        if (ivykis.Tipas != "Kontaktas.Susitikimas" && ivykis.Tipas != "Kontaktas.Telefonu - Rašytinis")
                        {
                            // incorrect, skip iterration, no result
                            continue;
                        }
                        else
                        {
                            // insert result
                            string.Format("insert into [ktu_gpt_training_data] (Sentence, EventType, Trigeris, version) values ('{0}','{1}','{2}','{3}')", ivykis.Apimtis, ivykis.Tipas, ivykis.Trigeris, version).ToSqlInsertUpdateDelete();
                        }
                    }
                    catch
                    {
                        // incorrect, skip iterration, no result
                        continue;
                    }

                }

            }
        }

        void gpt_dataset_good_examples_v5()
        {
            // initial parameters
            string version = "5";
            float gpt_temp = 0.7f;
            string gpt_model = OpenAI.ObjectModels.Models.Gpt_4o_mini;

            // WRR rule
            string komanda_zodziai = "select word from ktu_words";
            string[,] zodziai = komanda_zodziai.ToSqlSelect();

            // Regex pattern to find text inside square brackets
            string pattern = @"\[(.*?)\]";

            for (int x = 0; x < 999; x++) // x through zodziai (WRR)
            {
                Console.WriteLine(x);

                // TL, no more than 5 triggers, otherwise ask not to use
                string[,] trigeriai = string.Format("select * from (select count(id) cnt, trigeris from [ktu_gpt_training_data] where version = '{0}' group by trigeris) a where cnt > 4", version).ToSqlSelect();
                string nereikalingi_trigeriai = "";
                if (trigeriai.GetLength(0) > 0)
                {
                    for (int i = 0; i < trigeriai.GetLength(0); i++)
                    {
                        nereikalingi_trigeriai += trigeriai[i, 1] + ", ";
                    }
                }

                // prompt construction (generation request)
                string uzduotis = "";
                uzduotis += "Tai yra sakinių, kurie atitiktų aprašytam 1 arba 2 įvykių tipui sudarymo užduotis. Kiekvienam sudarytam sakiniui nurodyti ir trigerį. Išvesti PRIVALOMAI pateikti formatu kaip nurodyta pavyzdyje." + Environment.NewLine;
                // NO WRR
                //uzduotis += "Sudaryti sakiniai turi turėti šį žodį: " + zodziai[x, 0] + Environment.NewLine;
                if (trigeriai.GetLength(0) > 0)
                    uzduotis += "Sudaryti sakiniai turi neturėti šių žodžių: " + nereikalingi_trigeriai + Environment.NewLine;
                uzduotis += "Įvykio aprašymas ir užduoties įvykių tipai" + Environment.NewLine;
                uzduotis += "Įvykis yra vyksmas, kuriame dalyvauja jo dalyviai. Įvykis yra kažkas kas įvyksta. Įvykį taip pat galima apibūdinti kaip būsenos pokytį." + Environment.NewLine;
                uzduotis += "1.Kontaktas.Susitikimas: 2 ar daugiau subjektų(turi būti paminėti pvz.žmonės, šalys, įmonės) susitikimas tam tikroje vietoje fiziškai(akis į akį).Įeina pokalbiai, summit'ai, konferencijos, vizitai ir kiti susitikimai. Tam, kad sakinys atitiktų įvykį: Kontaktas.Susitikimas, jame turi būti aiškiai nusakyta, kad susitikimas kažkur vyksta fiziškai t.y. žmonės kažkur susitiko akis į akį. Pvz. \"GM kalbasi su Chrysler dėl Jeep įsigyjimo\" - nelaikytina susitikimo įvykiu." + Environment.NewLine;
                uzduotis += "2.Kontaktas.Telefonu - Rašytinis: 2 ar daugiau žmonių(turi būti paminėti) sukontaktuoja telefonu ar raštu(pvz.el.paštu) nuotoliu be fizinio susitikimo. \"Asmuo pasakė žurnalistams\" arba \"išleido pranešimą spaudai\" nėra šis įvykis." + Environment.NewLine;
                uzduotis += "Pavyzdys:" + Environment.NewLine;
                uzduotis += "Įvestis: Bušas ir Putinas šią savaitę susitiko aptarti reikalus dėl Čėčėnijos." + Environment.NewLine;
                uzduotis += "Išvestis: [{ \"Apimtis\":\"Bušas ir Putinas šią savaitę susitiko aptarti reikalus dėl Čėčėnijos.\",\"Trigeris\":\"susitiko\",\"Tipas\":\"Kontaktas.Susitikimas\"}]" + Environment.NewLine;
                string rez = uzduotis.ToGPT(gpt_temp, gpt_model);

                // Find matches
                MatchCollection matches = Regex.Matches(rez, pattern);

                // Print all matches
                foreach (Match match in matches)
                {
                    string dataBetweenBrackets = match.Groups[1].Value;
                    Ivykis ivykis = new Ivykis();

                    try
                    {
                        ivykis = JsonConvert.DeserializeObject<Ivykis>(dataBetweenBrackets);
                    }
                    catch
                    {
                        // incorrect, skip iterration, no result
                        continue;
                    }

                    try
                    {
                        if (ivykis.Tipas != "Kontaktas.Susitikimas" && ivykis.Tipas != "Kontaktas.Telefonu - Rašytinis")
                        {
                            // incorrect, skip iterration, no result
                            continue;
                        }
                        else
                        {
                            // insert result
                            string.Format("insert into [ktu_gpt_training_data] (Sentence, EventType, Trigeris, version) values ('{0}','{1}','{2}','{3}')", ivykis.Apimtis, ivykis.Tipas, ivykis.Trigeris, version).ToSqlInsertUpdateDelete();
                        }
                    }
                    catch
                    {
                        // incorrect, skip iterration, no result
                        continue;
                    }

                }

            }
        }

        void gpt_dataset_bad_examples_v3()
        {
            // initial parameters
            string version = "3";
            float gpt_temp = 1f;
            string gpt_model = OpenAI.ObjectModels.Models.Gpt_4o;

            // WRR rule
            string komanda_zodziai = "select word from ktu_words";
            string[,] zodziai = komanda_zodziai.ToSqlSelect();

            for (int x = 0; x < 11000; x++)
            {
                // TL rule
                string[,] trigeriai = string.Format("select * from (select count(id) cnt, trigeris from [ktu_gpt_training_data] where EventType = 'Ne' and version = '{0}' group by trigeris) a where cnt > 2", version).ToSqlSelect();
                string nereikalingi_trigeriai = "";
                if (trigeriai.GetLength(0) > 0)
                {
                    for (int i = 0; i < trigeriai.GetLength(0); i++)
                    {
                        nereikalingi_trigeriai += trigeriai[i, 1] + ", ";
                    }
                }

                // PROMPT
                string uzduotis = "";
                //uzduotis += "Tai yra sakinių, kurie atitiktų aprašytam 1 arba 2 įvykių tipui sudarymo užduotis. Kiekvienam sudarytam sakiniui nurodyti ir trigerį. Išvesti PRIVALOMAI pateikti formatu kaip nurodyta pavyzdyje." + Environment.NewLine;
                uzduotis += "Šioje užduotyje bus aprašyti 2 tipų įvykiai. Reikia pateikti sakinių, kurie nebūtų priskiriami nei vienam iš aprašytų įvykių. Išvesti PRIVALOMAI pateikti formatu kaip nurodyta pavyzdyje." + Environment.NewLine;
                uzduotis += "Sudaryti sakiniai turi turėti šį žodį: " + zodziai[x, 0] + Environment.NewLine;
                if (trigeriai.GetLength(0) > 0)
                    uzduotis += "Sudaryti sakiniai turi neturėti šių žodžių: " + nereikalingi_trigeriai + Environment.NewLine;
                uzduotis += "Įvykio aprašymas ir įvykių tipai, kuriems turi neatitikti sakiniai:" + Environment.NewLine;
                uzduotis += "Įvykis yra vyksmas, kuriame dalyvauja jo dalyviai. Įvykis yra kažkas kas įvyksta.Įvykį taip pat galima apibūdinti kaip būsenos pokytį." + Environment.NewLine;
                uzduotis += "1.Kontaktas.Susitikimas: 2 ar daugiau subjektų(turi būti paminėti pvz.žmonės, šalys, įmonės) susitikimas tam tikroje vietoje fiziškai(akis į akį).Įeina pokalbiai, summit'ai, konferencijos, vizitai ir kiti susitikimai. Tam, kad sakinys atitiktų įvykį: Kontaktas.Susitikimas, jame turi būti aiškiai nusakyta, kad susitikimas kažkur vyksta fiziškai t.y. žmonės kažkur susitiko akis į akį. Pvz. \"GM kalbasi su Chrysler dėl Jeep įsigyjimo\" - nelaikytina susitikimo įvykiu." + Environment.NewLine;
                uzduotis += "2.Kontaktas.Telefonu - Rašytinis: 2 ar daugiau žmonių(turi būti paminėti) sukontaktuoja telefonu ar raštu(pvz.el.paštu) nuotoliu be fizinio susitikimo. \"Asmuo pasakė žurnalistams\" arba \"išleido pranešimą spaudai\" nėra šis įvykis." + Environment.NewLine;
                uzduotis += "Sakinio, neatitinkančio aprašytus įvykius pavyzdys:" + Environment.NewLine;
                uzduotis += "Įvestis: Bušas ir Putinas šią savaitę balsavo savo šalyse." + Environment.NewLine;
                uzduotis += "Išvestis: [{ \"Apimtis\":\"Bušas ir Putinas šią savaitę balsavo savo šalyse.\",\"Trigeris\":\"balsavo\",\"Tipas\":\"Neatitinka\"}]" + Environment.NewLine;
                string rez = uzduotis.ToGPT(gpt_temp, gpt_model);

                // Regex pattern to find text inside square brackets
                string pattern = @"\[(.*?)\]";

                // Find matches
                MatchCollection matches = Regex.Matches(rez, pattern);
                int a = matches.Count;

                // Print all matches
                foreach (Match match in matches)
                {
                    string dataBetweenBrackets = match.Groups[1].Value;
                    Ivykis ivykis = new Ivykis();

                    try
                    {
                        ivykis = JsonConvert.DeserializeObject<Ivykis>(dataBetweenBrackets);
                    }
                    catch
                    {
                        // incorrect, skip iterration, no result
                        continue;
                    }

                    if (ivykis.Tipas.ToLower() == "neatitinka") 
                        ivykis.Tipas = "Ne";

                    if (ivykis.Tipas != "Ne")
                    {
                        // incorrect, skip iterration, no result
                        continue;
                    }

                    string.Format("insert into [ktu_gpt_training_data] (Sentence, EventType, Trigeris, version) values ('{0}','{1}','{2}','{3}')", ivykis.Apimtis, ivykis.Tipas, ivykis.Trigeris, version).ToSqlInsertUpdateDelete();
                }
            }
        }

        void gpt_dataset_bad_examples_v4()
        {
            // initial parameters
            string version = "4";
            float gpt_temp = 0.7f;
            string gpt_model = OpenAI.ObjectModels.Models.Gpt_4o_mini;

            // WRR rule
            string komanda_zodziai = "select word from ktu_words";
            string[,] zodziai = komanda_zodziai.ToSqlSelect();

            for (int x = 0; x < 11000; x++)
            {
                // TL rule
                string[,] trigeriai = string.Format("select * from (select count(id) cnt, trigeris from [ktu_gpt_training_data] where EventType = 'Ne' and version = '{0}' group by trigeris) a where cnt > 2", version).ToSqlSelect();
                string nereikalingi_trigeriai = "";
                if (trigeriai.GetLength(0) > 0)
                {
                    for (int i = 0; i < trigeriai.GetLength(0); i++)
                    {
                        nereikalingi_trigeriai += trigeriai[i, 1] + ", ";
                    }
                }

                // PROMPT
                string uzduotis = "";
                //uzduotis += "Tai yra sakinių, kurie atitiktų aprašytam 1 arba 2 įvykių tipui sudarymo užduotis. Kiekvienam sudarytam sakiniui nurodyti ir trigerį. Išvesti PRIVALOMAI pateikti formatu kaip nurodyta pavyzdyje." + Environment.NewLine;
                uzduotis += "Šioje užduotyje bus aprašyti 2 tipų įvykiai. Reikia pateikti sakinių, kurie nebūtų priskiriami nei vienam iš aprašytų įvykių. Išvesti PRIVALOMAI pateikti formatu kaip nurodyta pavyzdyje." + Environment.NewLine;
                uzduotis += "Sudaryti sakiniai turi turėti šį žodį: " + zodziai[x, 0] + Environment.NewLine;
                if (trigeriai.GetLength(0) > 0)
                    uzduotis += "Sudaryti sakiniai turi neturėti šių žodžių: " + nereikalingi_trigeriai + Environment.NewLine;
                uzduotis += "Įvykio aprašymas ir įvykių tipai, kuriems turi neatitikti sakiniai:" + Environment.NewLine;
                uzduotis += "Įvykis yra vyksmas, kuriame dalyvauja jo dalyviai. Įvykis yra kažkas kas įvyksta.Įvykį taip pat galima apibūdinti kaip būsenos pokytį." + Environment.NewLine;
                uzduotis += "1.Kontaktas.Susitikimas: 2 ar daugiau subjektų(turi būti paminėti pvz.žmonės, šalys, įmonės) susitikimas tam tikroje vietoje fiziškai(akis į akį).Įeina pokalbiai, summit'ai, konferencijos, vizitai ir kiti susitikimai. Tam, kad sakinys atitiktų įvykį: Kontaktas.Susitikimas, jame turi būti aiškiai nusakyta, kad susitikimas kažkur vyksta fiziškai t.y. žmonės kažkur susitiko akis į akį. Pvz. \"GM kalbasi su Chrysler dėl Jeep įsigyjimo\" - nelaikytina susitikimo įvykiu." + Environment.NewLine;
                uzduotis += "2.Kontaktas.Telefonu - Rašytinis: 2 ar daugiau žmonių(turi būti paminėti) sukontaktuoja telefonu ar raštu(pvz.el.paštu) nuotoliu be fizinio susitikimo. \"Asmuo pasakė žurnalistams\" arba \"išleido pranešimą spaudai\" nėra šis įvykis." + Environment.NewLine;
                uzduotis += "Sakinio, neatitinkančio aprašytus įvykius pavyzdys:" + Environment.NewLine;
                uzduotis += "Įvestis: Bušas ir Putinas šią savaitę balsavo savo šalyse." + Environment.NewLine;
                uzduotis += "Išvestis: [{ \"Apimtis\":\"Bušas ir Putinas šią savaitę balsavo savo šalyse.\",\"Trigeris\":\"balsavo\",\"Tipas\":\"Neatitinka\"}]" + Environment.NewLine;
                string rez = uzduotis.ToGPT(gpt_temp, gpt_model);

                // Regex pattern to find text inside square brackets
                string pattern = @"\[(.*?)\]";

                // Find matches
                MatchCollection matches = Regex.Matches(rez, pattern);
                int a = matches.Count;

                // Print all matches
                foreach (Match match in matches)
                {
                    string dataBetweenBrackets = match.Groups[1].Value;
                    Ivykis ivykis = new Ivykis();

                    try
                    {
                        ivykis = JsonConvert.DeserializeObject<Ivykis>(dataBetweenBrackets);
                    }
                    catch
                    {
                        // incorrect, skip iterration, no result
                        continue;
                    }

                    if (ivykis.Tipas.ToLower() == "neatitinka")
                        ivykis.Tipas = "Ne";

                    if (ivykis.Tipas != "Ne")
                    {
                        // incorrect, skip iterration, no result
                        continue;
                    }

                    string.Format("insert into [ktu_gpt_training_data] (Sentence, EventType, Trigeris, version) values ('{0}','{1}','{2}','{3}')", ivykis.Apimtis, ivykis.Tipas, ivykis.Trigeris, version).ToSqlInsertUpdateDelete();
                }
            }
        }

        void gpt_dataset_bad_examples_v5()
        {
            // initial parameters
            string version = "5";
            float gpt_temp = 0.7f;
            string gpt_model = OpenAI.ObjectModels.Models.Gpt_4o_mini;

            // WRR rule
            string komanda_zodziai = "select word from ktu_words";
            string[,] zodziai = komanda_zodziai.ToSqlSelect();

            for (int x = 0; x < 11000; x++)
            {
                // TL rule
                string[,] trigeriai = string.Format("select * from (select count(id) cnt, trigeris from [ktu_gpt_training_data] where EventType = 'Ne' and version = '{0}' group by trigeris) a where cnt > 2", version).ToSqlSelect();
                string nereikalingi_trigeriai = "";
                if (trigeriai.GetLength(0) > 0)
                {
                    for (int i = 0; i < trigeriai.GetLength(0); i++)
                    {
                        nereikalingi_trigeriai += trigeriai[i, 1] + ", ";
                    }
                }

                // PROMPT
                string uzduotis = "";
                //uzduotis += "Tai yra sakinių, kurie atitiktų aprašytam 1 arba 2 įvykių tipui sudarymo užduotis. Kiekvienam sudarytam sakiniui nurodyti ir trigerį. Išvesti PRIVALOMAI pateikti formatu kaip nurodyta pavyzdyje." + Environment.NewLine;
                uzduotis += "Šioje užduotyje bus aprašyti 2 tipų įvykiai. Reikia pateikti sakinių, kurie nebūtų priskiriami nei vienam iš aprašytų įvykių. Išvesti PRIVALOMAI pateikti formatu kaip nurodyta pavyzdyje." + Environment.NewLine;
                // NO WRR
                //uzduotis += "Sudaryti sakiniai turi turėti šį žodį: " + zodziai[x, 0] + Environment.NewLine;
                if (trigeriai.GetLength(0) > 0)
                    uzduotis += "Sudaryti sakiniai turi neturėti šių žodžių: " + nereikalingi_trigeriai + Environment.NewLine;
                uzduotis += "Įvykio aprašymas ir įvykių tipai, kuriems turi neatitikti sakiniai:" + Environment.NewLine;
                uzduotis += "Įvykis yra vyksmas, kuriame dalyvauja jo dalyviai. Įvykis yra kažkas kas įvyksta.Įvykį taip pat galima apibūdinti kaip būsenos pokytį." + Environment.NewLine;
                uzduotis += "1.Kontaktas.Susitikimas: 2 ar daugiau subjektų(turi būti paminėti pvz.žmonės, šalys, įmonės) susitikimas tam tikroje vietoje fiziškai(akis į akį).Įeina pokalbiai, summit'ai, konferencijos, vizitai ir kiti susitikimai. Tam, kad sakinys atitiktų įvykį: Kontaktas.Susitikimas, jame turi būti aiškiai nusakyta, kad susitikimas kažkur vyksta fiziškai t.y. žmonės kažkur susitiko akis į akį. Pvz. \"GM kalbasi su Chrysler dėl Jeep įsigyjimo\" - nelaikytina susitikimo įvykiu." + Environment.NewLine;
                uzduotis += "2.Kontaktas.Telefonu - Rašytinis: 2 ar daugiau žmonių(turi būti paminėti) sukontaktuoja telefonu ar raštu(pvz.el.paštu) nuotoliu be fizinio susitikimo. \"Asmuo pasakė žurnalistams\" arba \"išleido pranešimą spaudai\" nėra šis įvykis." + Environment.NewLine;
                uzduotis += "Sakinio, neatitinkančio aprašytus įvykius pavyzdys:" + Environment.NewLine;
                uzduotis += "Įvestis: Bušas ir Putinas šią savaitę balsavo savo šalyse." + Environment.NewLine;
                uzduotis += "Išvestis: [{ \"Apimtis\":\"Bušas ir Putinas šią savaitę balsavo savo šalyse.\",\"Trigeris\":\"balsavo\",\"Tipas\":\"Neatitinka\"}]" + Environment.NewLine;
                string rez = uzduotis.ToGPT(gpt_temp, gpt_model);

                // Regex pattern to find text inside square brackets
                string pattern = @"\[(.*?)\]";

                // Find matches
                MatchCollection matches = Regex.Matches(rez, pattern);
                int a = matches.Count;

                // Print all matches
                foreach (Match match in matches)
                {
                    string dataBetweenBrackets = match.Groups[1].Value;
                    Ivykis ivykis = new Ivykis();

                    try
                    {
                        ivykis = JsonConvert.DeserializeObject<Ivykis>(dataBetweenBrackets);
                    }
                    catch
                    {
                        // incorrect, skip iterration, no result
                        continue;
                    }

                    if (ivykis.Tipas.ToLower() == "neatitinka")
                        ivykis.Tipas = "Ne";

                    if (ivykis.Tipas != "Ne")
                    {
                        // incorrect, skip iterration, no result
                        continue;
                    }

                    string.Format("insert into [ktu_gpt_training_data] (Sentence, EventType, Trigeris, version) values ('{0}','{1}','{2}','{3}')", ivykis.Apimtis, ivykis.Tipas, ivykis.Trigeris, version).ToSqlInsertUpdateDelete();
                }
            }
        }

        void gpt_dataset_bad_examples_v2()
        {
            // 50 iteraciju, 250 pavyzdziu

            string komanda_zodziai = "select word from ktu_words";
            string[,] zodziai = komanda_zodziai.ToSqlSelect();

            float temperatura = 0.7f;

            for (int x = 36; x < 11000; x++)
            {
                string[,] trigeriai = "select * from (select count(id) cnt, trigeris from [ktu_gpt_training_data] where EventType = 'Ne' and v2 = 1 group by trigeris) a where cnt > 2".ToSqlSelect();
                string nereikalingi_trigeriai = "";
                if (trigeriai.GetLength(0) > 0)
                {
                    for (int i = 0; i < trigeriai.GetLength(0); i++)
                    {
                        nereikalingi_trigeriai += trigeriai[i, 1] + ", ";
                    }
                }

                string uzduotis = "";

                // pavyzdzio uzklausa
                //uzduotis += "Tai yra sakinių, kurie atitiktų aprašytam 1 arba 2 įvykių tipui sudarymo užduotis. Kiekvienam sudarytam sakiniui nurodyti ir trigerį. Išvesti PRIVALOMAI pateikti formatu kaip nurodyta pavyzdyje." + Environment.NewLine;
                uzduotis += "Šioje užduotyje bus aprašyti 2 tipų įvykiai. Reikia pateikti sakinių, kurie nebūtų priskiriami nei vienam iš aprašytų įvykių. Išvesti PRIVALOMAI pateikti formatu kaip nurodyta pavyzdyje." + Environment.NewLine;
                uzduotis += "Sudaryti sakiniai turi turėti šį žodį: " + zodziai[x, 0] + Environment.NewLine;
                if (trigeriai.GetLength(0) > 0)
                    uzduotis += "Sudaryti sakiniai turi neturėti šių žodžių: " + nereikalingi_trigeriai + Environment.NewLine;
                uzduotis += "Įvykio aprašymas ir įvykių tipai, kuriems turi neatitikti sakiniai:" + Environment.NewLine;
                uzduotis += "Įvykis yra vyksmas, kuriame dalyvauja jo dalyviai. Įvykis yra kažkas kas įvyksta.Įvykį taip pat galima apibūdinti kaip būsenos pokytį." + Environment.NewLine;
                uzduotis += "1.Kontaktas.Susitikimas: 2 ar daugiau subjektų(turi būti paminėti pvz.žmonės, šalys, įmonės) susitikimas tam tikroje vietoje fiziškai(akis į akį).Įeina pokalbiai, summit'ai, konferencijos, vizitai ir kiti susitikimai. Tam, kad sakinys atitiktų įvykį: Kontaktas.Susitikimas, jame turi būti aiškiai nusakyta, kad susitikimas kažkur vyksta fiziškai t.y. žmonės kažkur susitiko akis į akį. Pvz. \"GM kalbasi su Chrysler dėl Jeep įsigyjimo\" - nelaikytina susitikimo įvykiu." + Environment.NewLine;
                uzduotis += "2.Kontaktas.Telefonu - Rašytinis: 2 ar daugiau žmonių(turi būti paminėti) sukontaktuoja telefonu ar raštu(pvz.el.paštu) nuotoliu be fizinio susitikimo. \"Asmuo pasakė žurnalistams\" arba \"išleido pranešimą spaudai\" nėra šis įvykis." + Environment.NewLine;
                uzduotis += "Sakinio, neatitinkančio aprašytus įvykius pavyzdys:" + Environment.NewLine;
                uzduotis += "Įvestis: Bušas ir Putinas šią savaitę balsavo savo šalyse." + Environment.NewLine;
                uzduotis += "Išvestis: [{ \"Apimtis\":\"Bušas ir Putinas šią savaitę balsavo savo šalyse.\",\"Trigeris\":\"balsavo\",\"Tipas\":\"Neatitinka\"}]" + Environment.NewLine;

                string rez = uzduotis.ToGPT(0.7f, OpenAI.ObjectModels.Models.Gpt_4o);

                // Regex pattern to find text inside square brackets
                string pattern = @"\[(.*?)\]";

                // Find matches
                MatchCollection matches = Regex.Matches(rez, pattern);

                int a = matches.Count;

                // Print all matches
                foreach (Match match in matches)
                {
                    string dataBetweenBrackets = match.Groups[1].Value;
                    Ivykis ivykis = new Ivykis();

                    try
                    {
                        ivykis = JsonConvert.DeserializeObject<Ivykis>(dataBetweenBrackets);
                    }
                    catch
                    {
                        // anomalija gaunasi, kai sudetinis sakinys, tai isveda triguba rezultata
                        // tarsi ir teisingai dalinai


                        //MessageBox.Show("JSON konvertavimo klaida.");
                        //System.Environment.Exit(0);
                        //return ivykis;

                        //MessageBox.Show("Praleidžiama klaida: " + dataBetweenBrackets);

                        // jei buna sakinyje kabutes pvz cituoja kalba tai praleidzia
                        continue;
                    }

                    if (ivykis.Tipas == "Neatitinka") ivykis.Tipas = "Ne";

                    string.Format("insert into [ktu_gpt_training_data] (Sentence, EventType, Trigeris, v2) values ('{0}','{1}','{2}','1')", ivykis.Apimtis, ivykis.Tipas, ivykis.Trigeris).ToSqlInsertUpdateDelete();
                }
            }
        }

        void gpt_training_data_papildyti_sakiniai_be_ivykiu()
        {
            string[,] rez = "select sakinys, ivykio_tipas from [ktu_trigeriuzodynas] where ivykio_tipas = 'Ne'".ToSqlSelect();
            for (int i = 0; i < rez.GetLength(0); i = i + 7) // kas 7ta
            {
                string sakinys = rez[i, 0];
                string ivykio_tipas = rez[i, 1];

                string.Format("insert into [ktu_gpt_training_data] (Sentence, EventType) values ('{0}','{1}')", sakinys, ivykio_tipas).ToSqlInsertUpdateDelete();
            }
        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            //gpt_dataset_good_examples_v3();
            //gpt_dataset_good_examples_v2();
            //gpt_training_data_papildyti_sakiniai_be_ivykiu();

            //gpt_dataset_bad_examples_v2();
            //gpt_dataset_bad_examples_v3();
            //gpt_dataset_bad_examples_v4();
           // gpt_dataset_bad_examples_v5();

            //training_data_sudarymas_is_etaloniniu_anotaciju();

            //gpt_dataset_good_examples_v4();
            //gpt_dataset_good_examples_v5();

            MessageBox.Show("Done");
            return;

            string uzduotis = "";
            uzduotis += "Tai yra šioje užduotyje pateiktų 1 iš 2 įvykių tipų ir jų laiko nustatymo užduotis. Užduoties tekstu galimai pateikiamas tik 1 įvykis. Jeigu pateikiamas tekstas yra vienas iš reikiamų atpažinti įvykių, pateikti struktūrizuotą išvestį pagal pavyzdį. Kitu atveju, pateikti atsakymą: nenustatyta." + Environment.NewLine + Environment.NewLine;
            uzduotis += "Įvykio aprašymas ir užduoties įvykių tipai" + Environment.NewLine + Environment.NewLine;
            uzduotis += "Įvykis yra vyksmas, kuriame dalyvauja jo dalyviai. Įvykis yra kažkas kas įvyksta. Įvykį taip pat galima apibūdinti kaip būsenos pokytį." + Environment.NewLine + Environment.NewLine;
            uzduotis += "1. Kontaktas.Susitikimas: 2 ar daugiau subjektų (turi būti paminėti pvz. žmonės, šalys, įmonės) susitikimas tam tikroje vietoje fiziškai (akis į akį). Įeina pokalbiai, summit'ai, konferencijos, vizitai ir kiti susitikimai. Tam, kad sakinys atitiktų įvykį: Kontaktas.Susitikimas, jame turi būti aiškiai nusakyta, kad susitikimas kažkur vyksta fiziškai t.y. žmonės kažkur susitiko akis į akį. Pvz. \"GM kalbasi su Chrysler dėl Jeep įsigyjimo\" - nelaikytina susitikimo įvykiu." + Environment.NewLine;
            uzduotis += "2. Kontaktas.Telefonu-Rašytinis: 2 ar daugiau žmonių (turi būti paminėti) sukontaktuoja telefonu ar raštu (pvz. el. paštu) nuotoliu be fizinio susitikimo. \"Asmuo pasakė žurnalistams\" arba \"išleido pranešimą spaudai\" nėra šis įvykis." + Environment.NewLine + Environment.NewLine;
            uzduotis += "Geri pavyzdžiai:" + Environment.NewLine + Environment.NewLine;
            uzduotis += "Įvestis: Bušas ir Putinas šią savaitę susitiko aptarti reikalus dėl Čėčėnijos." + Environment.NewLine;
            uzduotis += "Išvestis: [{\"Trigeris\":\"susitiko\",\"Laikas\":\"šią savaitę\",\"Tipas\":\"Kontaktas.Susitikimas\"}]" + Environment.NewLine + Environment.NewLine;
            uzduotis += "Įvestis: Džonas išsiuntė el. laišką Džeinei." + Environment.NewLine;
            uzduotis += "Išvestis: [{\"Trigeris\":\"išsiuntė\",\"Laikas\":\"\",\"Tipas\":\"Telefonu-Rašytinis\"}]" + Environment.NewLine + Environment.NewLine;
            uzduotis += "Blogi pavyzdžiai:" + Environment.NewLine + Environment.NewLine;
            uzduotis += "Įvestis: GM jau metus kalbasi su Chrysler dėl Jeep įsigyjimo." + Environment.NewLine;
            uzduotis += "Išvestis: [{\"Trigeris\":\"kalbasi\",\"Laikas\":\"metus\",\"Tipas\":\"Kontaktas.Susitikimas\"}]" + Environment.NewLine + Environment.NewLine;
            uzduotis += "Įvestis: Prezidentas Nausėda pareiškė žurnalistas, kad kitais metais kandidatuos į prezidentus." + Environment.NewLine;
            uzduotis += "Išvestis: [{\"Trigeris\":\"pareiškė\",\"Laikas\":\"kitais metais\",\"Tipas\":\"Telefonu-Rašytinis\"}]" + Environment.NewLine + Environment.NewLine;

            //straipsnio_spalvinimo_nuemimas();            
        }

        void zodyno_sudarymas()
        {
            string[,] rez = "select anotacijos, id from ktu_articles where anotacijos_Gpt_4_1106_preview is not null".ToSqlSelect();

            anotacijos_obj = new Anotacijos();
            anotacijos_obj.Ivykiai = new List<Ivykis> { };

            // einama per visus straipsnius
            for (int i = 0; i < rez.GetLength(0); i++)
            {
                // straipsnio json anotacijos
                string straipsnio_anotacijos = rez[i, 0];

                // eiti per kiekviena sakini, tikrinti ar anotacija
                if (straipsnio_anotacijos.IsNullOrEmpty() || straipsnio_anotacijos.Length == 14)
                {

                }
                else
                {
                    if (straipsnio_anotacijos.Length > 25)
                    {
                        Anotacijos anotacijos_obj2 = new Anotacijos();
                        anotacijos_obj2.Ivykiai = new List<Ivykis> { };
                        anotacijos_obj2 = JsonConvert.DeserializeObject<Anotacijos>(straipsnio_anotacijos);

                        anotacijos_obj.Ivykiai.AddRange(anotacijos_obj2.Ivykiai);
                        //spalvinti_anotacijas();
                    }
                }


            }

            //anotacijosjsonBox.Text = straipsnio_anotacijos;

            string rezultatas = "";

            for (int i = 0; i < anotacijos_obj.Ivykiai.Count; i++)
            {
                rezultatas += anotacijos_obj.Ivykiai[i].Tipas + " - " + anotacijos_obj.Ivykiai[i].Trigeris + Environment.NewLine;
                string.Format("insert into ktu_trigeriuzodynas (sakinys, ivykio_tipas, trigeris) values ('{0}','{1}')", anotacijos_obj.Ivykiai[i].Tipas, anotacijos_obj.Ivykiai[i].Trigeris).ToSqlInsertUpdateDelete();
            }

            straipsnisBox.Text = rezultatas;
        }

        private void zodyninisanotavimasButton_Click(object sender, EventArgs e)
        {
            //string metodika = metodikaBox.Text.ToString();

            //if (!metodikos_irasymo_tikrinimas_passed())
            //    return;

            string max_id = "9999"; // ~20 straipsniu

            string komanda = "select id, antraste, tekstas, straipsnis from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and anotacijos_zodyno is null and id < " + max_id;

            string[,] rez = komanda.ToSqlSelect();

            // einama per visus straipsnius vertintinus
            for (int i = 0; i < rez.GetLength(0); i++)
            {
                string id = rez[i, 0].ToString();

                // jeigu ne taip, o tiesiai tai pasimeta indeksas
                //straipsnisBox.Text = rez[0, 1] + Environment.NewLine + Environment.NewLine + rez[0, 2];
                string tekstas = rez[i, 3];

                zodyninis_automatinis_suanotavimas(tekstas, id);
            }

            MessageBox.Show("Automatinis ŽODYNINIS anotavimas baigtas.");
        }

        private void zodyniniuanotacijuikrovimasButton_Click(object sender, EventArgs e)
        {
            straipsnio_spalvinimo_nuemimas();

            string[,] rez = ("select anotacijos_zodyno from ktu_articles where id = " + ikrauto_straipsnio_id).ToSqlSelect();

            string anotacijos = rez[0, 0];

            ikrauti_anotacijas(anotacijos);

            mlanotacijosButton.Visible = true;
            etaloniniuanotacijuikrovimasButton.Visible = true;
            gptanotacijuikrovimasButton.Visible = true;
            zodyniniuanotacijuikrovimasButton.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            for (int i = 1; i < 6; i++)
            {
                string version = i.ToString();
                string algo = "LR"; // SBE, FT, LR

                MLModel ML = new MLModel(null, null); // null - because it doesnt need to load model, we just create a new one here
                ML.CreateNewModel(version, algo);
            }

            MessageBox.Show("Done");

            //var mlContext = new MLContext(seed: 0);

            //var sqlCommand = "SELECT [id],[Sakinys],[Ivykio_tipas],[Trigeris],[Json_anotacija] FROM [Cobra].[dbo].[ktu_trainingdata]";

            //Connection c = new Connection();

            //// Create database loader
            //var databaseSource = new DatabaseSource(SqlClientFactory.Instance, c.con, sqlCommand);
            //var loader = mlContext.Data.CreateDatabaseLoader<InputData>();

            //// Load data from SQL
            //IDataView data = loader.Load(databaseSource);

            //// Split the data into training and testing datasets and define data transformations
            //var preprocessingPipeline = mlContext.Transforms.Conversion.MapValueToKey(outputColumnName: "Label", inputColumnName: nameof(CustomerData.Purchased))
            //.Append(mlContext.Transforms.Concatenate("Features", nameof(CustomerData.Age), nameof(CustomerData.Income)))
            //.Append(mlContext.Transforms.NormalizeMinMax("Features"));

            //// Mokymo algoritmo nustatymas
            //var trainingPipeline = preprocessingPipeline.Append(mlContext.BinaryClassification.Trainers.LbfgsLogisticRegression(labelColumnName: "Label", featureColumnName: "Features"));


            //var model = trainingPipeline.Fit(trainData);

        }

        void word_statistics_renew()
        {
            // Dictionary to store word frequencies
            Dictionary<string, int> wordCount = new Dictionary<string, int>();

            // Articles
            string komanda = "select id, straipsnis from [ktu_articles]"; // top 10 reiktu nuimti visiems
            string[,] rez = komanda.ToSqlSelect();
            int kiekis = rez.GetLength(0);
            Regex regex = new Regex(@"\b[a-zA-Z]{2,}\b");
            //kiekis = 10; // testui

            for (int i = 0; i < kiekis; i++)
            {
                string straipsnis = rez[i, 1];

                var matches = regex.Matches(straipsnis.ToLower());

                // Count each word's occurrence
                foreach (Match match in matches)
                {
                    string word = match.Value;

                    if (wordCount.ContainsKey(word))
                    {
                        wordCount[word]++;
                    }
                    else
                    {
                        wordCount[word] = 1;
                    }
                }
            }

            // Order words by frequency (descending) and display them
            var orderedWordCount = wordCount.OrderByDescending(x => x.Value);

            Console.WriteLine("Word frequencies:");
            foreach (var word in orderedWordCount)
            {
                Console.WriteLine($"{word.Key}: {word.Value}");
                string komanda_iterpimo = string.Format("insert into ktu_words (word, kiekis) values ('{0}','{1}')", word.Key, word.Value);
                komanda_iterpimo.ToSqlInsertUpdateDelete();
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            //string rezas = "Labas".ToGemini();

            //word_statistics_renew();

            MessageBox.Show("Done");
            return;

            MLModel ml = new MLModel(null, null);

            string[,] rez = "select anotacijos, id, tekstas from ktu_articles where anotavimas_baigtas = 1 and anotacijos is not null".ToSqlSelect();

            // einama per visus straipsnius
            for (int i = 0; i < rez.GetLength(0); i++)
            {
                // straipsnio json anotacijos
                string straipsnio_anotacijos = rez[i, 0];
                string straipsnio_id = rez[i, 1];
                string straipsnio_tekstas = rez[i, 2];

                var props = new Properties();
                props.setProperty("annotators", "tokenize,ssplit");
                var pipeline = new StanfordCoreNLP(props);
                var annotation = new Annotation(straipsnio_tekstas);
                pipeline.annotate(annotation);
                var sentences = annotation.get(typeof(CoreAnnotations.SentencesAnnotation));

                // sudedami neanotuoti sakiniai
                foreach (var sentence in sentences as ArrayList)
                {
                    string sakinys = sentence.ToString();

                    MessageBox.Show(sakinys + Environment.NewLine + ml.Predict(sakinys));
                }
            }

        }

        private void mlanotavimasButton_Click(object sender, EventArgs e)
        {
            for (int v = 1; v < 6; v++)
            {
                string version = v.ToString(); // 1-5
                string algo = "lr"; // sme / ft / lr
                MLmodel = new MLModel(version, algo); // model is initiated

                string combo = algo + version; // column name sme1-5/ft1-5/lr-1-5
                string komanda = string.Format("select id, straipsnis from [ktu_articles] where [anotavimas_baigtas] = 1 and anotacijos like '%Kontaktas%' and {0} is null", combo);

                string[,] rez = komanda.ToSqlSelect();

                // einama per visus straipsnius vertintinus
                for (int i = 0; i < rez.GetLength(0); i++)
                {
                    string id = rez[i, 0].ToString();
                    string tekstas = rez[i, 1]; // straipsnis = antraste + tekstas = full

                    ml_automatinis_suanotavimas(tekstas, id, combo);
                }
            }

            MessageBox.Show("Automatinis ML anotavimas baigtas.");
        }

        private void mlanotacijosButton_Click(object sender, EventArgs e)
        {
            straipsnio_spalvinimo_nuemimas();

            string[,] rez = ("select anotacijos_ml_v2 from ktu_articles where id = " + ikrauto_straipsnio_id).ToSqlSelect();

            string ml_anotacijos = rez[0, 0];

            ikrauti_anotacijas(ml_anotacijos);

            mlanotacijosButton.Visible = false;
            etaloniniuanotacijuikrovimasButton.Visible = true;
            gptanotacijuikrovimasButton.Visible = true;
            zodyniniuanotacijuikrovimasButton.Visible = true;
        }

        //using (Spacy.Initialize(Spacy.ModelSize.Large, Language.Any, Language.Lithuanian))
        //{
        //    var nlp = Spacy.For(Spacy.ModelSize.Large, Language.Lithuanian);
        //    var doc = new Document("This is a test of integrating Spacy and Catalyst", Language.English);
        //    nlp.ProcessSingle(doc);
        //    MessageBox.Show(doc.ToJson());
        //}

        //static async Task<string> DoSomethingAsync()
        //{
        //    using (await Spacy.Initialize(Spacy.ModelSize.Small, Language.Any, Language.English))
        //    {
        //        var nlp = Spacy.For(Spacy.ModelSize.Small, Language.Eglish);
        //        var doc = new Document("This is a test of integrating Spacy and Catalyst", Language.English);
        //        nlp.ProcessSingle(doc);
        //        Console.WriteLine(doc.ToJson());
        //    }
        //}
    }
}