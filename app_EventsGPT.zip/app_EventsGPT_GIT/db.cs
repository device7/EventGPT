﻿using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Events
{
    public class db
    {
        Connection c = new Connection();
        public bool be_klaidos = true;
        public db()
        {
        }

        public void sql_insertupdate(string command)
        {

            using (SqlConnection conn = new SqlConnection(c.con))
            {
                be_klaidos = true;
                conn.Open();
                SqlCommand cmd = new SqlCommand(command, conn);
                cmd.ExecuteNonQuery();
            }
        }

        public DataTable sql_select(string command, bool exit_on_error = true)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection conn = new SqlConnection(c.con))
                {
                    be_klaidos = true;
                    conn.Open();
                    SqlDataAdapter da = new SqlDataAdapter(command, c.con);
                    da.SelectCommand.CommandTimeout = 600;
                    da.Fill(dt);
                }
            }
            catch (Exception ee)
            {
                if (exit_on_error)
                {
                    MessageBox.Show(command + "\n\n" + ee.ToString());
                    be_klaidos = false;
                }
            }

            return dt;
        }
    }
}
