﻿using OpenAI.Managers;
using OpenAI;
using OpenAI.ObjectModels.RequestModels;
using OpenAI.ObjectModels;
using System.Data;
using Events;
using sun.tools.tree;
using System.Text;
using System.Text.Json.Nodes;
using static edu.stanford.nlp.fsm.TransducerGraph;
using Newtonsoft.Json.Linq;

namespace ExtensionMethods
{
    public static class MyExtensions
    {

        public static double RoundDoubleToDouble(this double str, int kiek)
        {
            return Math.Round(str, kiek);
        }

        public static string ToGPT(this String str, float temp, string model)
        {
            int tokens = 4000;
            try
            {
                var task = Task.Run(async () => await str.ToGPTAsync(tokens, temp, model));
                return task.Result;
            }
            catch
            (Exception ex)
            {
                return "";
            }
        }

        public static string ToGemini(this String str)
        {
            string apiKey = ""; // SetToStringNodeProcessor apikey
            //string endpointUrl = "https://vertex-ai.googleapis.com/v1/projects/YOUR_PROJECT_ID/locations/us-central1/endpoints/YOUR_ENDPOINT_ID:predict";
            string url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=" + apiKey;
            //string url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro-latest:generateContent?key=" + apiKey;

            string jsonBody = $@"{{
    ""contents"": [
        {{
            ""parts"": [
                {{ ""text"": ""{EscapeJsonString(str)}"" }}
            ]
        }}
    ]
}}";

            using (HttpClient client = new HttpClient())
            {
                // Prepare the request body and specify the content type
                StringContent content = new StringContent(jsonBody, Encoding.UTF8, "application/json");

                // Make a synchronous POST request
                HttpResponseMessage response = client.PostAsync(url, content).Result;

                // Handle the response
                if (response.IsSuccessStatusCode)
                {
                    return ExtractTextFromResponse(response.Content.ReadAsStringAsync().Result);
                }
                else
                {
                    return $"Error: {response.StatusCode}";
                }
            }
        
    }

        public static string ExtractTextFromResponse(string jsonResponse)
        {
            // Parse the JSON response
            var parsedResponse = JObject.Parse(jsonResponse);

            if (!jsonResponse.ToLower().Contains("text"))
                return "NOTSAFE";

            // Navigate the JSON structure to get the text value
            try
            {
                string extractedText = parsedResponse["candidates"][0]["content"]["parts"][0]["text"].ToString();

                return extractedText;
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR (GEMINI ANSWER EXTRACTION): " + ex.ToString());
                return "";
            }
        }

        public static string EscapeJsonString(string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                return input; // Return as-is if the input is null or empty.
            }

            StringBuilder sb = new StringBuilder();

            foreach (char c in input)
            {
                switch (c)
                {
                    case '\\':
                        sb.Append("\\\\"); // Escape backslashes.
                        break;
                    case '\"':
                        sb.Append("\\\""); // Escape double quotes.
                        break;
                    case '\n':
                        sb.Append("\\n"); // Escape newlines.
                        break;
                    case '\r':
                        sb.Append("\\r"); // Escape carriage returns.
                        break;
                    case '\t':
                        sb.Append("\\t"); // Escape tabs.
                        break;
                    default:
                        sb.Append(c); // Leave other characters as-is.
                        break;
                }
            }

            return sb.ToString();
        }

        public static async Task<string> ToGPTAsync(this String str, int tokens, float temp, string model)
        {
            // gpt3 https://github.com/betalgo/openai/wiki/Chat-GPT
            // kiti https://github.com/betalgo/openai

            var apiKey = ""; // set api key

            var gpt = new OpenAIService(new OpenAiOptions()
            {
                ApiKey = apiKey
            });

            var completionResult = await gpt.ChatCompletion.CreateCompletion
                                   (new ChatCompletionCreateRequest()
                                   {
                                       Messages = new List<ChatMessage>(new ChatMessage[]
                { new ChatMessage("user", str) }),
                                       Model = model, //Models.Gpt_4o,
                                       Temperature = temp,
                                    });

            string rezultatas = "";

            // Gpt_4_1106_preview yra gpt4turbo 0.01 uz tukstanti ivesti ir 0.03 uz isvesti
            // paprastas gpt4 brangesnis

            if (completionResult.Successful)
            {
                foreach (var choice in completionResult.Choices)
                {
                    if (rezultatas.IsNotNullOrEmpty())
                        rezultatas += "\n";

                    rezultatas += choice.Message.Content;
                }
            }
            else
            {
                if (completionResult.Error == null)
                {
                    rezultatas = "Unknown Error";
                }

                rezultatas = completionResult.Error.Message;
            }


            return rezultatas;

        }

        public static bool IsNotNullOrEmpty(this String str)
        {
            if (!String.IsNullOrEmpty(str))
                return true;
            else
                return false;
        }

        public static int ToInt32(this String str)
        {
            return Convert.ToInt32(str);
        }

        public static string[,] ToSqlSelect(this String str, bool exit_on_error = true)
        {
            db dbcmd = new db();
            DataTable temp = dbcmd.sql_select(str, exit_on_error);

            int kolumnu_kiekis = temp.Columns.Count;
            int eiluciu_kiekis = temp.Rows.Count;

            string[,] rezultatas = new string[eiluciu_kiekis, kolumnu_kiekis];

            for (int i = 0; i < eiluciu_kiekis; i++)
            {
                for (int j = 0; j < kolumnu_kiekis; j++)
                {
                    rezultatas[i, j] = temp.Rows[i].ItemArray[j].ToString();
                }
            }

            return rezultatas;
        }

        public static Boolean ToBoolean(this String str)
        {
            if (str == "1" || str == "True")
                return true;
            else
                return false;
        }

        public static int BoolToInt(this Boolean str)
        {
            if (str)
                return 1;
            else
                return 0;
        }

        public static void ToSqlInsertUpdateDelete(this String str)
        {
            try
            {
                db dbcmd = new db();
                dbcmd.sql_insertupdate(str);
            }
            catch { }
        }

        public static bool IsNullOrEmpty(this String str)
        {
            return String.IsNullOrEmpty(str);
        }
    }
}