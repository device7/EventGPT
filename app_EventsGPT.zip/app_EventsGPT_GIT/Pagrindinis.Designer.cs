﻿namespace Events
{
    partial class ivykiaiForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label3 = new Label();
            dataCombo = new ComboBox();
            straipsniaiCombo = new ComboBox();
            label2 = new Label();
            baigtasCheck = new CheckBox();
            idBox = new TextBox();
            straipsnisBox = new RichTextBox();
            anotacijosjsonBox = new RichTextBox();
            dataBox = new TextBox();
            pavadinimasBox = new TextBox();
            kategorijaBox = new TextBox();
            anotuotojasBox = new TextBox();
            label1 = new Label();
            gptanotavimasButton = new Button();
            issaugotianotacijasButton = new Button();
            gptanotacijuikrovimasButton = new Button();
            etaloniniuanotacijuikrovimasButton = new Button();
            ivertinimasButton = new Button();
            button1 = new Button();
            label4 = new Label();
            label5 = new Label();
            metodikaBox = new TextBox();
            zodyninisanotavimasButton = new Button();
            zodyniniuanotacijuikrovimasButton = new Button();
            button3 = new Button();
            button2 = new Button();
            button4 = new Button();
            mlanotavimasButton = new Button();
            mlanotacijosButton = new Button();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(19, 15);
            label3.Name = "label3";
            label3.Size = new Size(44, 20);
            label3.TabIndex = 0;
            label3.Text = "Data:";
            // 
            // dataCombo
            // 
            dataCombo.DropDownStyle = ComboBoxStyle.DropDownList;
            dataCombo.FormattingEnabled = true;
            dataCombo.Location = new Point(106, 12);
            dataCombo.Name = "dataCombo";
            dataCombo.Size = new Size(401, 28);
            dataCombo.TabIndex = 1;
            // 
            // straipsniaiCombo
            // 
            straipsniaiCombo.DropDownStyle = ComboBoxStyle.DropDownList;
            straipsniaiCombo.FormattingEnabled = true;
            straipsniaiCombo.Location = new Point(106, 45);
            straipsniaiCombo.Name = "straipsniaiCombo";
            straipsniaiCombo.Size = new Size(401, 28);
            straipsniaiCombo.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(19, 49);
            label2.Name = "label2";
            label2.Size = new Size(81, 20);
            label2.TabIndex = 2;
            label2.Text = "Straipsniai:";
            // 
            // baigtasCheck
            // 
            baigtasCheck.AutoSize = true;
            baigtasCheck.Location = new Point(1004, 79);
            baigtasCheck.Name = "baigtasCheck";
            baigtasCheck.Size = new Size(80, 24);
            baigtasCheck.TabIndex = 4;
            baigtasCheck.Text = "Baigtas";
            baigtasCheck.UseVisualStyleBackColor = true;
            // 
            // idBox
            // 
            idBox.Location = new Point(1203, 15);
            idBox.Name = "idBox";
            idBox.Size = new Size(125, 27);
            idBox.TabIndex = 5;
            // 
            // straipsnisBox
            // 
            straipsnisBox.Location = new Point(19, 147);
            straipsnisBox.Name = "straipsnisBox";
            straipsnisBox.ReadOnly = true;
            straipsnisBox.Size = new Size(1079, 562);
            straipsnisBox.TabIndex = 7;
            straipsnisBox.Text = "";
            // 
            // anotacijosjsonBox
            // 
            anotacijosjsonBox.Location = new Point(1104, 145);
            anotacijosjsonBox.Name = "anotacijosjsonBox";
            anotacijosjsonBox.ReadOnly = true;
            anotacijosjsonBox.Size = new Size(224, 109);
            anotacijosjsonBox.TabIndex = 8;
            anotacijosjsonBox.Text = "";
            // 
            // dataBox
            // 
            dataBox.Location = new Point(19, 112);
            dataBox.Name = "dataBox";
            dataBox.ReadOnly = true;
            dataBox.Size = new Size(488, 27);
            dataBox.TabIndex = 9;
            // 
            // pavadinimasBox
            // 
            pavadinimasBox.Location = new Point(513, 112);
            pavadinimasBox.Name = "pavadinimasBox";
            pavadinimasBox.ReadOnly = true;
            pavadinimasBox.Size = new Size(585, 27);
            pavadinimasBox.TabIndex = 10;
            // 
            // kategorijaBox
            // 
            kategorijaBox.Location = new Point(106, 79);
            kategorijaBox.Name = "kategorijaBox";
            kategorijaBox.Size = new Size(401, 27);
            kategorijaBox.TabIndex = 11;
            // 
            // anotuotojasBox
            // 
            anotuotojasBox.Location = new Point(1104, 81);
            anotuotojasBox.Name = "anotuotojasBox";
            anotuotojasBox.Size = new Size(224, 27);
            anotuotojasBox.TabIndex = 12;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(19, 81);
            label1.Name = "label1";
            label1.Size = new Size(81, 20);
            label1.TabIndex = 13;
            label1.Text = "Kategorija:";
            // 
            // gptanotavimasButton
            // 
            gptanotavimasButton.Location = new Point(1104, 538);
            gptanotavimasButton.Name = "gptanotavimasButton";
            gptanotavimasButton.Size = new Size(224, 53);
            gptanotavimasButton.TabIndex = 14;
            gptanotavimasButton.Text = "Automatinis LLM anotavimas (visų neanotuotų)";
            gptanotavimasButton.UseVisualStyleBackColor = true;
            gptanotavimasButton.Click += button1_Click;
            // 
            // issaugotianotacijasButton
            // 
            issaugotianotacijasButton.Location = new Point(1104, 114);
            issaugotianotacijasButton.Name = "issaugotianotacijasButton";
            issaugotianotacijasButton.Size = new Size(224, 29);
            issaugotianotacijasButton.TabIndex = 16;
            issaugotianotacijasButton.Text = "Išsaugoti anotacijas";
            issaugotianotacijasButton.UseVisualStyleBackColor = true;
            issaugotianotacijasButton.Click += button2_Click;
            // 
            // gptanotacijuikrovimasButton
            // 
            gptanotacijuikrovimasButton.Location = new Point(689, 28);
            gptanotacijuikrovimasButton.Name = "gptanotacijuikrovimasButton";
            gptanotacijuikrovimasButton.Size = new Size(226, 25);
            gptanotacijuikrovimasButton.TabIndex = 17;
            gptanotacijuikrovimasButton.Text = "GPT anotacijų įkrovimas";
            gptanotacijuikrovimasButton.UseVisualStyleBackColor = true;
            gptanotacijuikrovimasButton.Visible = false;
            gptanotacijuikrovimasButton.Click += gptanotacijuikrovimasButton_Click;
            // 
            // etaloniniuanotacijuikrovimasButton
            // 
            etaloniniuanotacijuikrovimasButton.Location = new Point(689, 77);
            etaloniniuanotacijuikrovimasButton.Name = "etaloniniuanotacijuikrovimasButton";
            etaloniniuanotacijuikrovimasButton.Size = new Size(226, 26);
            etaloniniuanotacijuikrovimasButton.TabIndex = 18;
            etaloniniuanotacijuikrovimasButton.Text = "Etaloninių anotacijų įkrovimas";
            etaloniniuanotacijuikrovimasButton.UseVisualStyleBackColor = true;
            etaloniniuanotacijuikrovimasButton.Visible = false;
            etaloniniuanotacijuikrovimasButton.Click += etaloniniuanotacijuikrovimasButton_Click;
            // 
            // ivertinimasButton
            // 
            ivertinimasButton.Location = new Point(1104, 323);
            ivertinimasButton.Name = "ivertinimasButton";
            ivertinimasButton.Size = new Size(224, 56);
            ivertinimasButton.TabIndex = 19;
            ivertinimasButton.Text = "Įvertinimas (visų straipsnių)";
            ivertinimasButton.UseVisualStyleBackColor = true;
            ivertinimasButton.Click += ivertinimasButton_Click;
            // 
            // button1
            // 
            button1.Location = new Point(1104, 260);
            button1.Name = "button1";
            button1.Size = new Size(224, 57);
            button1.TabIndex = 20;
            button1.Text = "Įvertinimas (atidaryto)";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(1100, 18);
            label4.Name = "label4";
            label4.Size = new Size(97, 20);
            label4.TabIndex = 21;
            label4.Text = "Straipsnio ID:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(967, 49);
            label5.Name = "label5";
            label5.Size = new Size(230, 20);
            label5.TabIndex = 23;
            label5.Text = "Metodika (1,2,3,4,zodyno,ml,ml2):";
            // 
            // metodikaBox
            // 
            metodikaBox.Location = new Point(1203, 48);
            metodikaBox.Name = "metodikaBox";
            metodikaBox.Size = new Size(125, 27);
            metodikaBox.TabIndex = 22;
            // 
            // zodyninisanotavimasButton
            // 
            zodyninisanotavimasButton.Location = new Point(1104, 597);
            zodyninisanotavimasButton.Name = "zodyninisanotavimasButton";
            zodyninisanotavimasButton.Size = new Size(224, 53);
            zodyninisanotavimasButton.TabIndex = 25;
            zodyninisanotavimasButton.Text = "Automatinis ŽODYNYNIS anotavimas (visų neanotuotų)";
            zodyninisanotavimasButton.UseVisualStyleBackColor = true;
            zodyninisanotavimasButton.Click += zodyninisanotavimasButton_Click;
            // 
            // zodyniniuanotacijuikrovimasButton
            // 
            zodyniniuanotacijuikrovimasButton.Location = new Point(689, 53);
            zodyniniuanotacijuikrovimasButton.Name = "zodyniniuanotacijuikrovimasButton";
            zodyniniuanotacijuikrovimasButton.Size = new Size(226, 25);
            zodyniniuanotacijuikrovimasButton.TabIndex = 26;
            zodyniniuanotacijuikrovimasButton.Text = "Žodyninių anotacijų įkrovimas";
            zodyniniuanotacijuikrovimasButton.UseVisualStyleBackColor = true;
            zodyniniuanotacijuikrovimasButton.Visible = false;
            zodyniniuanotacijuikrovimasButton.Click += zodyniniuanotacijuikrovimasButton_Click;
            // 
            // button3
            // 
            button3.Location = new Point(536, 46);
            button3.Name = "button3";
            button3.Size = new Size(127, 29);
            button3.TabIndex = 27;
            button3.Text = "Create Model";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Location = new Point(536, 14);
            button2.Name = "button2";
            button2.Size = new Size(127, 29);
            button2.TabIndex = 24;
            button2.Text = "Make DataSet";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click_2;
            // 
            // button4
            // 
            button4.Location = new Point(536, 79);
            button4.Name = "button4";
            button4.Size = new Size(127, 29);
            button4.TabIndex = 28;
            button4.Text = "Test";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // mlanotavimasButton
            // 
            mlanotavimasButton.Location = new Point(1104, 656);
            mlanotavimasButton.Name = "mlanotavimasButton";
            mlanotavimasButton.Size = new Size(224, 53);
            mlanotavimasButton.TabIndex = 29;
            mlanotavimasButton.Text = "Automatinis ML anotavimas (visų neanotuotų)";
            mlanotavimasButton.UseVisualStyleBackColor = true;
            mlanotavimasButton.Click += mlanotavimasButton_Click;
            // 
            // mlanotacijosButton
            // 
            mlanotacijosButton.Location = new Point(689, 3);
            mlanotacijosButton.Name = "mlanotacijosButton";
            mlanotacijosButton.Size = new Size(226, 25);
            mlanotacijosButton.TabIndex = 30;
            mlanotacijosButton.Text = "ML anotacijų įkrovimas";
            mlanotacijosButton.UseVisualStyleBackColor = true;
            mlanotacijosButton.Visible = false;
            mlanotacijosButton.Click += mlanotacijosButton_Click;
            // 
            // ivykiaiForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1350, 721);
            Controls.Add(mlanotacijosButton);
            Controls.Add(mlanotavimasButton);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(zodyniniuanotacijuikrovimasButton);
            Controls.Add(zodyninisanotavimasButton);
            Controls.Add(button2);
            Controls.Add(label5);
            Controls.Add(metodikaBox);
            Controls.Add(label4);
            Controls.Add(button1);
            Controls.Add(ivertinimasButton);
            Controls.Add(etaloniniuanotacijuikrovimasButton);
            Controls.Add(gptanotacijuikrovimasButton);
            Controls.Add(issaugotianotacijasButton);
            Controls.Add(gptanotavimasButton);
            Controls.Add(label1);
            Controls.Add(anotuotojasBox);
            Controls.Add(kategorijaBox);
            Controls.Add(pavadinimasBox);
            Controls.Add(dataBox);
            Controls.Add(anotacijosjsonBox);
            Controls.Add(straipsnisBox);
            Controls.Add(idBox);
            Controls.Add(baigtasCheck);
            Controls.Add(straipsniaiCombo);
            Controls.Add(label2);
            Controls.Add(dataCombo);
            Controls.Add(label3);
            Name = "ivykiaiForm";
            Text = "Įvykiai";
            Load += ivykiaiForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label3;
        private ComboBox dataCombo;
        private ComboBox straipsniaiCombo;
        private Label label2;
        private CheckBox baigtasCheck;
        private TextBox idBox;
        private RichTextBox straipsnisBox;
        private RichTextBox anotacijosjsonBox;
        private TextBox dataBox;
        private TextBox pavadinimasBox;
        private TextBox kategorijaBox;
        private TextBox anotuotojasBox;
        private Label label1;
        private Button gptanotavimasButton;
        private Button issaugotianotacijasButton;
        private Button gptanotacijuikrovimasButton;
        private Button etaloniniuanotacijuikrovimasButton;
        private Button ivertinimasButton;
        private Button button1;
        private Label label4;
        private Label label5;
        private TextBox metodikaBox;
        private Button zodyninisanotavimasButton;
        private Button zodyniniuanotacijuikrovimasButton;
        private Button button3;
        private Button button2;
        private Button button4;
        private Button mlanotavimasButton;
        private Button mlanotacijosButton;
    }
}