﻿using ExtensionMethods;
using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Events
{
    public partial class IvykisForm : Form
    {
        public Ivykis ivykis;

        string mention_tekstas = "";
        string mention_indeksas = "";
        string mention_ilgis = "";

        string trigeris_indeksas = "";
        string trigeris_ilgis = "";

        string laikas_indeksas = "";
        string laikas_ilgis = "";

        Bendri b;
        ContextMenuStrip meniu = new ContextMenuStrip();
        Anotacijos anotacijos_obj;

        public int redaguojamos_anotacijos_id = -1;
        public int naikinamos_anotacijos_id = -1;
        public bool ok_click = false;
        public IvykisForm(string mention_tekstas, string mention_indeksas, string mention_ilgis,
            Anotacijos anotacijos_obj)
        {
            InitializeComponent();

            this.anotacijos_obj = anotacijos_obj;
            this.mention_tekstas = mention_tekstas;
            this.mention_indeksas = mention_indeksas;
            this.mention_ilgis = mention_ilgis;

            b = new Bendri();

            b.form_nustatymai_default(this, "Įvykis");

            ivykismentionBox.Text = mention_tekstas.Trim();
            ivykiotipu_ikrovimas();

            kontekstinis_meniu();
            rasti_ikrauti();
        }

        void rasti_ikrauti()
        {
            for (int i = 0; i < anotacijos_obj.Ivykiai.Count; i++)
            {
                if (anotacijos_obj.Ivykiai[i].Apimtis == mention_tekstas)
                {
                    ivykiotipasCombo.SelectedIndex = ivykiotipasCombo.FindString(anotacijos_obj.Ivykiai[i].Tipas);

                    ivykiolaikasBox.Text = anotacijos_obj.Ivykiai[i].Laikas;
                    laikas_indeksas = anotacijos_obj.Ivykiai[i].Laikas_indeksas;
                    laikas_ilgis = anotacijos_obj.Ivykiai[i].Laikas_ilgis;

                    ivykiotrigerisBox.Text = anotacijos_obj.Ivykiai[i].Trigeris;
                    trigeris_indeksas = anotacijos_obj.Ivykiai[i].Trigeris_indeksas;
                    trigeris_ilgis = anotacijos_obj.Ivykiai[i].Trigeris_ilgis;

                    redaguojamos_anotacijos_id = i;
                    naikintiButton.Visible = true;
                    break;
                }
            }
        }

        private void kontekstinis_meniu()
        {
            meniu = new ContextMenuStrip();
            ToolStripMenuItem trigeris = new ToolStripMenuItem("Trigeris");
            ToolStripMenuItem laikas = new ToolStripMenuItem("Laikas");

            trigeris.Click += Trigeris_Click;
            laikas.Click += Laikas_Click;

            meniu.Items.AddRange(new ToolStripItem[] { trigeris, laikas });

            // papildomi eventai
            ivykismentionBox.MouseDown += IvykismentionBox_MouseDown;
        }

        private void IvykismentionBox_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                // Get the current mouse position
                Point mousePosition = Control.MousePosition;

                // Show the ContextMenuStrip at the mouse position
                meniu.Show(mousePosition);
            }
        }

        bool patikra_passed(string tekstas, string tipas)
        {
            // tikrinti ar pirmas ir paskutinis simboliai yra raides
            if (!Char.IsLetter(tekstas[0]) || !Char.IsLetter(tekstas[tekstas.Length - 1]))
            {
                if (tipas == "Laikas")
                {
                    const string message = "Pirmas ir paskutinis simboliai turi būti ne simboliai. Jei OK, spauskite Taip.";
                    const string caption = "Patikra";
                    var result = MessageBox.Show(message, caption,
                                                 MessageBoxButtons.YesNo,
                                                 MessageBoxIcon.Question);

                    if (result == DialogResult.No)
                        return false;
                }
                else
                {
                    MessageBox.Show("Pirmas ir paskutinis simboliai turi būti ne simboliai.");
                    return false;
                }
            }

            // tikrinti ar nera tarpu ar simboliu, jei trigeris
            if (tipas == "Trigeris")
            {
                for (int i = 0; i < tekstas.Length; i++)
                {
                    if (!Char.IsLetter(tekstas[i]))
                    {
                        MessageBox.Show("Trigeris negali turėti tarpų ar simbolių.");
                        return false;
                    }
                }
            }

            return true;
        }

        private void Laikas_Click(object sender, EventArgs e)
        {
            // pradinis nuskaitymas
            string Text = ivykismentionBox.SelectedText;
            int StartIndex = ivykismentionBox.SelectionStart;
            int Length = ivykismentionBox.SelectionLength;

            // pradzios nutrinimas ir indeksu perskaiciavimas, jei reikia
            string trimmedTextStart = Text.TrimStart();
            if (trimmedTextStart.Length != Text.Length)
            {
                StartIndex = StartIndex + (Text.Length - trimmedTextStart.Length);
                Text = trimmedTextStart;
                Length = Text.Length;
            }

            string trimmedTextEnd = Text.TrimEnd();
            if (trimmedTextEnd.Length != Text.Length)
            {
                // start indeksas nesikeicia, tik ilgis
                Text = trimmedTextEnd;
                Length = Text.Length;
            }

            if (!patikra_passed(Text, "Laikas"))
                return;

            ivykiolaikasBox.Text = Text;
            laikas_indeksas = StartIndex.ToString();
            laikas_ilgis = Length.ToString();


            //int selectionStart = ivykismentionBox.SelectionStart;
            //int selectionLength = ivykismentionBox.SelectionLength;
            //string selectedText = ivykismentionBox.SelectedText;

            //laikas_indeksas = selectionStart.ToString();
            //laikas_ilgis = selectionLength.ToString();
            //ivykiolaikasBox.Text = selectedText;
        }

        private void Trigeris_Click(object sender, EventArgs e)
        {
            // pradinis nuskaitymas
            string Text = ivykismentionBox.SelectedText;
            int StartIndex = ivykismentionBox.SelectionStart;
            int Length = ivykismentionBox.SelectionLength;

            // pradzios nutrinimas ir indeksu perskaiciavimas, jei reikia
            string trimmedTextStart = Text.TrimStart();
            if (trimmedTextStart.Length != Text.Length)
            {
                StartIndex = StartIndex + (Text.Length - trimmedTextStart.Length);
                Text = trimmedTextStart;
                Length = Text.Length;
            }

            string trimmedTextEnd = Text.TrimEnd();
            if (trimmedTextEnd.Length != Text.Length)
            {
                // start indeksas nesikeicia, tik ilgis
                Text = trimmedTextEnd;
                Length = Text.Length;
            }

            if (!patikra_passed(Text, "Trigeris"))
                return;

            ivykiotrigerisBox.Text = Text;
            trigeris_indeksas = StartIndex.ToString();
            trigeris_ilgis = Length.ToString();

            //int selectionStart = ivykismentionBox.SelectionStart;
            //int selectionLength = ivykismentionBox.SelectionLength;
            //string selectedText = ivykismentionBox.SelectedText;

            //trigeris_indeksas = selectionStart.ToString();
            //trigeris_ilgis = selectionLength.ToString();
            //ivykiotrigerisBox.Text = selectedText;
        }

        void ivykiotipu_ikrovimas()
        {
            string[,] rez = "select tipas, id from ktu_ivykiutipai".ToSqlSelect();

            for (int i = 0; i < rez.GetLength(0); i++)
            {
                string tipas = rez[i, 0];
                string id = rez[i, 1];

                ivykiotipasCombo.Items.Add(tipas + "-" + id);
            }
        }

        private void okButton_Click_1(object sender, EventArgs e)
        {
            ok_click = true;

            ivykis = new Ivykis
            {
                Apimtis = mention_tekstas,
                Apimtis_indeksas = mention_indeksas,
                Apimtis_ilgis = mention_ilgis,

                Tipas = ivykiotipasCombo.Text.ToString(),

                Trigeris = ivykiotrigerisBox.Text.ToString(),
                Trigeris_indeksas = trigeris_indeksas,
                Trigeris_ilgis = trigeris_ilgis,

                Laikas = ivykiolaikasBox.Text.ToString(),
                Laikas_indeksas = laikas_indeksas,
                Laikas_ilgis = laikas_ilgis
            };

            this.Close();
        }

        private void naikintiButton_Click_1(object sender, EventArgs e)
        {
            ok_click = true;

            naikinamos_anotacijos_id = redaguojamos_anotacijos_id;

            this.Close();
        }
    }
}
